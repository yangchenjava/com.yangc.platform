﻿SET DEFINE OFF;
Insert into T_BLOG_ATTR
   (ID, ATTR_NAME, ATTR_VALUE, DESCRIPTION)
 Values
   (110, 'blog_name', 'yangc-blog', '博客名称');
COMMIT;
