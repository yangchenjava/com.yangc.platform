﻿SET DEFINE OFF;
--SQL Statement which produced this data:
--
--  SELECT * FROM YANGC.T_SYS_ROLE;
--
Insert into T_SYS_ROLE
   (ID, ROLE_NAME, CREATE_USER, CREATE_TIME)
 Values
   (30, '系统管理员', 1, TO_DATE('09/21/2012 17:52:28', 'MM/DD/YYYY HH24:MI:SS'));
Insert into T_SYS_ROLE
   (ID, ROLE_NAME, CREATE_USER, CREATE_TIME)
 Values
   (42, '普通用户', 1, TO_DATE('09/26/2012 14:13:38', 'MM/DD/YYYY HH24:MI:SS'));
COMMIT;
