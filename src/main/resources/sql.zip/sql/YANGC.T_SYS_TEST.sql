﻿SET DEFINE OFF;
--SQL Statement which produced this data:
--
--  SELECT * FROM YANGC.T_SYS_TEST;
--
Insert into T_SYS_TEST
   (ID, NAME, VALUE)
 Values
   (1, 'yang', 'y1');
Insert into T_SYS_TEST
   (ID, NAME, VALUE)
 Values
   (2, 'yang', 'y2');
Insert into T_SYS_TEST
   (ID, NAME, VALUE)
 Values
   (3, 'zhu', 'z3');
Insert into T_SYS_TEST
   (ID, NAME, VALUE)
 Values
   (4, 'xu', 'x4');
Insert into T_SYS_TEST
   (ID, NAME, VALUE)
 Values
   (5, 'zhu', 'z5');
Insert into T_SYS_TEST
   (ID, NAME, VALUE)
 Values
   (6, 'yang', 'y6');
COMMIT;
