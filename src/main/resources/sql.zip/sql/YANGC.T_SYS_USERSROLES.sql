﻿SET DEFINE OFF;
--SQL Statement which produced this data:
--
--  SELECT * FROM YANGC.T_SYS_USERSROLES;
--
Insert into T_SYS_USERSROLES
   (ID, USER_ID, ROLE_ID)
 Values
   (47, 1, 30);
Insert into T_SYS_USERSROLES
   (ID, USER_ID, ROLE_ID)
 Values
   (48, 1, 42);
Insert into T_SYS_USERSROLES
   (ID, USER_ID, ROLE_ID)
 Values
   (51, 23, 42);
Insert into T_SYS_USERSROLES
   (ID, USER_ID, ROLE_ID)
 Values
   (52, 28, 42);
Insert into T_SYS_USERSROLES
   (ID, USER_ID, ROLE_ID)
 Values
   (103, 101, 42);
COMMIT;
