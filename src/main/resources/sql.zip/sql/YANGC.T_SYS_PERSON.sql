﻿SET DEFINE OFF;
--SQL Statement which produced this data:
--
--  SELECT * FROM YANGC.T_SYS_PERSON;
--
Insert into T_SYS_PERSON
   (ID, NAME, SEX, PHONE, DEPT_ID, 
    CREATE_USER, CREATE_TIME, UPDATE_USER, UPDATE_TIME, SPELL)
 Values
   (1, '杨晨', 1, '13718922561', 1, 
    1, TO_DATE('09/15/2012 23:19:07', 'MM/DD/YYYY HH24:MI:SS'), 1, TO_DATE('09/15/2012 23:19:07', 'MM/DD/YYYY HH24:MI:SS'), 'yangchen yc');
Insert into T_SYS_PERSON
   (ID, NAME, SEX, PHONE, DEPT_ID, 
    CREATE_USER, CREATE_TIME, SPELL)
 Values
   (22, '朱春生', 1, '15810483900', 1, 
    1, TO_DATE('09/15/2012 23:02:27', 'MM/DD/YYYY HH24:MI:SS'), 'zhuchunsheng zcs');
Insert into T_SYS_PERSON
   (ID, NAME, SEX, PHONE, DEPT_ID, 
    CREATE_USER, CREATE_TIME, SPELL)
 Values
   (27, '王省', 1, '15652667600', 1, 
    1, TO_DATE('09/17/2012 13:39:49', 'MM/DD/YYYY HH24:MI:SS'), 'wangsheng ws');
Insert into T_SYS_PERSON
   (ID, NAME, SEX, PHONE, DEPT_ID, 
    CREATE_USER, CREATE_TIME, UPDATE_USER, UPDATE_TIME, SPELL)
 Values
   (100, '测试', 0, '138', 3, 
    1, TO_DATE('05/23/2014 18:38:28', 'MM/DD/YYYY HH24:MI:SS'), 1, TO_DATE('05/23/2014 18:38:42', 'MM/DD/YYYY HH24:MI:SS'), 'ceshi cs');
COMMIT;
