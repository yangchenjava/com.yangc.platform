/*
 Navicat MySQL Data Transfer

 Source Server         : localhost
 Source Server Type    : MySQL
 Source Server Version : 50620
 Source Host           : localhost
 Source Database       : blog

 Target Server Type    : MySQL
 Target Server Version : 50620
 File Encoding         : utf-8

 Date: 08/10/2014 21:28:29 PM
*/

SET NAMES utf8;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
--  Table structure for `T_BLOG_ARTICLE`
-- ----------------------------
DROP TABLE IF EXISTS `T_BLOG_ARTICLE`;
CREATE TABLE `T_BLOG_ARTICLE` (
  `ID` int(22) NOT NULL AUTO_INCREMENT,
  `TITLE` varchar(200) DEFAULT NULL,
  `CONTENT` longtext,
  `CATEGORY_ID` int(22) DEFAULT NULL,
  `READ_COUNT` int(22) DEFAULT NULL,
  `CREATE_USER` int(22) DEFAULT NULL,
  `CREATE_TIME` datetime DEFAULT NULL,
  `UPDATE_USER` int(22) DEFAULT NULL,
  `UPDATE_TIME` datetime DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `ID` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
--  Table structure for `T_BLOG_ATTR`
-- ----------------------------
DROP TABLE IF EXISTS `T_BLOG_ATTR`;
CREATE TABLE `T_BLOG_ATTR` (
  `ID` int(22) NOT NULL AUTO_INCREMENT,
  `ATTR_NAME` varchar(200) DEFAULT NULL,
  `ATTR_VALUE` varchar(200) DEFAULT NULL,
  `DESCRIPTION` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `ID` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
--  Table structure for `T_BLOG_CATEGORY`
-- ----------------------------
DROP TABLE IF EXISTS `T_BLOG_CATEGORY`;
CREATE TABLE `T_BLOG_CATEGORY` (
  `ID` int(22) NOT NULL AUTO_INCREMENT,
  `CATEGORY_NAME` varchar(200) DEFAULT NULL,
  `PARENT_CATEGORY_ID` int(22) DEFAULT NULL,
  `SERIAL_NUM` int(22) DEFAULT NULL,
  `CREATE_USER` int(22) DEFAULT NULL,
  `CREATE_TIME` datetime DEFAULT NULL,
  `UPDATE_USER` int(22) DEFAULT NULL,
  `UPDATE_TIME` datetime DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `ID` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
--  Table structure for `T_BLOG_COMMENT`
-- ----------------------------
DROP TABLE IF EXISTS `T_BLOG_COMMENT`;
CREATE TABLE `T_BLOG_COMMENT` (
  `ID` int(22) NOT NULL AUTO_INCREMENT,
  `NAME` varchar(200) DEFAULT NULL,
  `CONTENT` varchar(1000) DEFAULT NULL,
  `ARTICLE_ID` int(22) DEFAULT NULL,
  `IP_ADDRESS` varchar(200) DEFAULT NULL,
  `CREATE_TIME` datetime DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `ID` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
--  Table structure for `T_BLOG_TAG`
-- ----------------------------
DROP TABLE IF EXISTS `T_BLOG_TAG`;
CREATE TABLE `T_BLOG_TAG` (
  `ID` int(22) NOT NULL AUTO_INCREMENT,
  `TAG_NAME` varchar(200) DEFAULT NULL,
  `ARTICLE_ID` int(22) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `ID` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
--  Table structure for `T_SYS_ACL`
-- ----------------------------
DROP TABLE IF EXISTS `T_SYS_ACL`;
CREATE TABLE `T_SYS_ACL` (
  `ID` int(22) NOT NULL AUTO_INCREMENT,
  `ROLE_ID` int(22) DEFAULT NULL,
  `MENU_ID` int(22) DEFAULT NULL,
  `OPERATE_STATUS` int(22) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `ID` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
--  Table structure for `T_SYS_DEPARTMENT`
-- ----------------------------
DROP TABLE IF EXISTS `T_SYS_DEPARTMENT`;
CREATE TABLE `T_SYS_DEPARTMENT` (
  `ID` int(22) NOT NULL AUTO_INCREMENT,
  `DEPT_NAME` varchar(200) DEFAULT NULL,
  `SERIAL_NUM` int(22) DEFAULT NULL,
  `CREATE_USER` int(22) DEFAULT NULL,
  `CREATE_TIME` datetime DEFAULT NULL,
  `UPDATE_USER` int(22) DEFAULT NULL,
  `UPDATE_TIME` datetime DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `ID` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
--  Table structure for `T_SYS_MENU`
-- ----------------------------
DROP TABLE IF EXISTS `T_SYS_MENU`;
CREATE TABLE `T_SYS_MENU` (
  `ID` int(22) NOT NULL AUTO_INCREMENT,
  `MENU_NAME` varchar(200) DEFAULT NULL,
  `MENU_ALIAS` varchar(200) DEFAULT NULL,
  `MENU_URL` varchar(200) DEFAULT NULL,
  `PARENT_MENU_ID` int(22) DEFAULT NULL,
  `SERIAL_NUM` int(22) DEFAULT NULL,
  `ISSHOW` int(1) DEFAULT NULL,
  `DESCRIPTION` varchar(200) DEFAULT NULL,
  `CREATE_USER` int(22) DEFAULT NULL,
  `CREATE_TIME` datetime DEFAULT NULL,
  `UPDATE_USER` int(22) DEFAULT NULL,
  `UPDATE_TIME` datetime DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `ID` (`ID`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
--  Table structure for `T_SYS_PERSON`
-- ----------------------------
DROP TABLE IF EXISTS `T_SYS_PERSON`;
CREATE TABLE `T_SYS_PERSON` (
  `ID` int(22) NOT NULL AUTO_INCREMENT,
  `NAME` varchar(50) DEFAULT NULL,
  `SEX` int(1) DEFAULT NULL,
  `PHONE` varchar(50) DEFAULT NULL,
  `SPELL` varchar(100) DEFAULT NULL,
  `DEPT_ID` int(22) DEFAULT NULL,
  `CREATE_USER` int(22) DEFAULT NULL,
  `CREATE_TIME` datetime DEFAULT NULL,
  `UPDATE_USER` int(22) DEFAULT NULL,
  `UPDATE_TIME` datetime DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `ID` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
--  Table structure for `T_SYS_ROLE`
-- ----------------------------
DROP TABLE IF EXISTS `T_SYS_ROLE`;
CREATE TABLE `T_SYS_ROLE` (
  `ID` int(22) NOT NULL AUTO_INCREMENT,
  `ROLE_NAME` varchar(200) DEFAULT NULL,
  `CREATE_USER` int(22) DEFAULT NULL,
  `CREATE_TIME` datetime DEFAULT NULL,
  `UPDATE_USER` int(22) DEFAULT NULL,
  `UPDATE_TIME` datetime DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `ID` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
--  Table structure for `T_SYS_USER`
-- ----------------------------
DROP TABLE IF EXISTS `T_SYS_USER`;
CREATE TABLE `T_SYS_USER` (
  `ID` int(22) NOT NULL AUTO_INCREMENT,
  `USERNAME` varchar(200) DEFAULT NULL,
  `PASSWORD` varchar(200) DEFAULT NULL,
  `PERSON_ID` int(22) DEFAULT NULL,
  `CREATE_USER` int(22) DEFAULT NULL,
  `CREATE_TIME` datetime DEFAULT NULL,
  `UPDATE_USER` int(22) DEFAULT NULL,
  `UPDATE_TIME` datetime DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `ID` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
--  Table structure for `T_SYS_USERSROLES`
-- ----------------------------
DROP TABLE IF EXISTS `T_SYS_USERSROLES`;
CREATE TABLE `T_SYS_USERSROLES` (
  `ID` int(22) NOT NULL AUTO_INCREMENT,
  `USER_ID` int(22) DEFAULT NULL,
  `ROLE_ID` int(22) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `ID` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

SET FOREIGN_KEY_CHECKS = 1;
