/*
 Navicat Premium Data Transfer

 Source Server         : localhost
 Source Server Type    : MySQL
 Source Server Version : 50620
 Source Host           : localhost
 Source Database       : blog

 Target Server Type    : MySQL
 Target Server Version : 50620
 File Encoding         : utf-8

 Date: 07/20/2015 21:52:36 PM
*/

SET NAMES utf8;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
--  Table structure for `T_BLOG_ARTICLE`
-- ----------------------------
DROP TABLE IF EXISTS `T_BLOG_ARTICLE`;
CREATE TABLE `T_BLOG_ARTICLE` (
  `ID` int(22) NOT NULL AUTO_INCREMENT,
  `TITLE` varchar(200) DEFAULT NULL,
  `CONTENT` longtext,
  `CATEGORY_ID` int(22) DEFAULT NULL,
  `READ_COUNT` int(22) DEFAULT NULL,
  `CREATE_USER` int(22) DEFAULT NULL,
  `CREATE_TIME` datetime DEFAULT NULL,
  `UPDATE_USER` int(22) DEFAULT NULL,
  `UPDATE_TIME` datetime DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `ID` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=146 DEFAULT CHARSET=utf8;

-- ----------------------------
--  Records of `T_BLOG_ARTICLE`
-- ----------------------------
BEGIN;
INSERT INTO `T_BLOG_ARTICLE` VALUES ('136', 'JVM_体系结构', '<p style=\"text-align:center\"><img src=\"/../upload/image/20140731/1406803467993030229.jpeg\" title=\"1406803467993030229.jpeg\" alt=\"2012050808411063.jpeg\"/></p><p style=\"font-family: 微软雅黑; font-size: 14px; white-space: normal;\">下面先对图中各部分做个简单的说明：</p><p style=\"font-family: 微软雅黑; font-size: 14px; white-space: normal;\">1.class文件：虚拟机并不关心Class的来源是什么语言，只要它符合Java class文件格式就可以在Java虚拟机中运行。使用Java编译器可以把Java代码编译为存储字节码的Class文件，使用JRuby等其他语言的编译器一样可以把程序代码编译成Class文件。</p><p style=\"font-family: 微软雅黑; font-size: 14px; white-space: normal;\">2.类装载器子系统：负责查找并装载Class 文件到内存，最终形成可以被虚拟机直接使用的Java类型。</p><p style=\"font-family: 微软雅黑; font-size: 14px; white-space: normal;\">3.方法区：在类装载器加载class文件到内存的过程中，虚拟机会提取其中的类型信息，并将这些信息存储到方法区。方法区用于存储已被虚拟机加载的类信息、常量、静态变量、即时编译器编译后的代码等数据。由于所有线程都共享方法区，因此它们对方法区数据的访问必须被设计为是线程安全的。</p><p style=\"font-family: 微软雅黑; font-size: 14px; white-space: normal;\">4.堆：存储Java程序创建的类实例。所有线程共享，因此设计程序时也要考虑到多线程访问对象(堆数据)的同步问题。</p><p style=\"font-family: 微软雅黑; font-size: 14px; white-space: normal;\">5.Java栈：Java栈是线程私有的。每当启动一个新线程时，Java虚拟机都会为它分配一个Java栈。Java栈以帧为单位保存线程的运行状态。虚拟机只会直接对Java栈执行两种操作：以帧为单位的压栈或出栈。当线程调用java方法时，虚拟机压入一个新的栈帧到该线程的java栈中。当方法返回时，这个栈帧被从java栈中弹出并抛弃。一个栈帧包含一个java方法的调用状态，它存储有局部变量表、操作栈、动态链接、方法出口等信息。</p><p style=\"font-family: 微软雅黑; font-size: 14px; white-space: normal;\">&nbsp;6.程序计数器：一个运行中的Java程序，每当启动一个新线程时，都会为这个新线程创建一个自己的PC(程序计数器)寄存器。程序计数器的作用可以看做是当前线程所执行的字节码的行号指示器。字节码解释器工作时就是通过改变这个计数器的值来选取下一条需要执行的字节码指令，分支、循环、跳转、异常处理、线程恢复等基础功能都需要依赖这个计数器来完成。如果线程正在执行的是一个Java方法，这个计数器记录的是正在执行的虚拟机字节码指令的地址；如果正在执行的是Natvie方法，这个计数器值则为空(Undefined)。</p><p style=\"font-family: 微软雅黑; font-size: 14px; white-space: normal;\">7.本地方法栈：本地方法栈与虚拟机栈所发挥的作用是非常相似的，其区别不过是虚拟机栈为虚拟机执行Java方法（也就是字节码）服务，而本地方法栈则是为虚拟机使用到的Native方法服务。任何本地方法接口都会使用某种本地方法栈。当线程调用Java方法时，虚拟机会创建一个新的栈帧并压入Java栈。然而当它调用的是本地方法时，虚拟机会保持Java栈不变，不再在线程的Java栈中压入新的帧，虚拟机只是简单地动态链接并直接调用指定的本地方法。如果某个虚拟机实现的本地方法接口是使用C连接模型的话，那么它的本地方法栈就是C栈。</p><p style=\"font-family: 微软雅黑; font-size: 14px; white-space: normal;\">8.执行引擎：负责执行字节码。方法的字节码是由Java虚拟机的指令序列构成的。每一条指令包含一个单字节的操作码，后面跟随0个或多个操作数。执行引擎执行字节码时，首先取得一个操作码，如果操作码有操作数，取得它的操作数。它执行操作码和跟随的操作数规定的动作，然后再取得下一个操作码。这个执行字节码的过程在线程完成前将一直持续。</p><p><br/></p>', '112', '115', '1', '2014-07-31 18:50:19', null, null), ('145', 'test', '<p>test</p><p>df</p><p>sdfs</p><p>sdfsf</p>', '116', '0', '1', '2014-08-01 13:52:52', null, null);
COMMIT;

-- ----------------------------
--  Table structure for `T_BLOG_ATTR`
-- ----------------------------
DROP TABLE IF EXISTS `T_BLOG_ATTR`;
CREATE TABLE `T_BLOG_ATTR` (
  `ID` int(22) NOT NULL AUTO_INCREMENT,
  `ATTR_NAME` varchar(200) DEFAULT NULL,
  `ATTR_VALUE` varchar(200) DEFAULT NULL,
  `DESCRIPTION` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `ID` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=136 DEFAULT CHARSET=utf8;

-- ----------------------------
--  Records of `T_BLOG_ATTR`
-- ----------------------------
BEGIN;
INSERT INTO `T_BLOG_ATTR` VALUES ('110', 'nickname', '烤馍', '昵称'), ('133', 'qq', '511636835', 'QQ'), ('134', 'github', 'yangchenjava', 'GitHub'), ('135', 'email', 'yangchen_java@126.com', '邮箱');
COMMIT;

-- ----------------------------
--  Table structure for `T_BLOG_CATEGORY`
-- ----------------------------
DROP TABLE IF EXISTS `T_BLOG_CATEGORY`;
CREATE TABLE `T_BLOG_CATEGORY` (
  `ID` int(22) NOT NULL AUTO_INCREMENT,
  `CATEGORY_NAME` varchar(200) DEFAULT NULL,
  `PARENT_CATEGORY_ID` int(22) DEFAULT NULL,
  `SERIAL_NUM` int(22) DEFAULT NULL,
  `CREATE_USER` int(22) DEFAULT NULL,
  `CREATE_TIME` datetime DEFAULT NULL,
  `UPDATE_USER` int(22) DEFAULT NULL,
  `UPDATE_TIME` datetime DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `ID` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=119 DEFAULT CHARSET=utf8;

-- ----------------------------
--  Records of `T_BLOG_CATEGORY`
-- ----------------------------
BEGIN;
INSERT INTO `T_BLOG_CATEGORY` VALUES ('112', 'Java', '0', '1', '1', '2014-07-18 15:31:17', null, null), ('113', '前端', '0', '2', '1', '2014-07-18 15:36:09', null, null), ('114', '缓存', '0', '3', '1', '2014-07-18 15:39:54', null, null), ('115', 'JS', '113', '1', '1', '2014-07-18 15:40:44', null, null), ('116', 'Jquery', '113', '2', '1', '2014-07-18 15:50:22', null, null), ('117', 'ExtJS', '113', '3', '1', '2014-07-18 15:50:48', null, null), ('118', '文章类别', null, '1', '1', '2014-07-17 00:00:00', null, null);
COMMIT;

-- ----------------------------
--  Table structure for `T_BLOG_COMMENT`
-- ----------------------------
DROP TABLE IF EXISTS `T_BLOG_COMMENT`;
CREATE TABLE `T_BLOG_COMMENT` (
  `ID` int(22) NOT NULL AUTO_INCREMENT,
  `NAME` varchar(200) DEFAULT NULL,
  `CONTENT` varchar(1000) DEFAULT NULL,
  `ARTICLE_ID` int(22) DEFAULT NULL,
  `IP_ADDRESS` varchar(200) DEFAULT NULL,
  `CREATE_TIME` datetime DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `ID` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=148 DEFAULT CHARSET=utf8;

-- ----------------------------
--  Records of `T_BLOG_COMMENT`
-- ----------------------------
BEGIN;
INSERT INTO `T_BLOG_COMMENT` VALUES ('146', 'yangc', '还不错，可以理解，评论文字的颜色清晰些就更好了。。。', '136', '127.0.0.1', '2014-08-04 19:12:50'), ('147', 'jeckson', '@yangc 我也是这么认为', '136', '127.0.0.1', '2014-08-04 19:15:38');
COMMIT;

-- ----------------------------
--  Table structure for `T_BLOG_TAG`
-- ----------------------------
DROP TABLE IF EXISTS `T_BLOG_TAG`;
CREATE TABLE `T_BLOG_TAG` (
  `ID` int(22) NOT NULL AUTO_INCREMENT,
  `TAG_NAME` varchar(200) DEFAULT NULL,
  `ARTICLE_ID` int(22) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `ID` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
--  Records of `T_BLOG_TAG`
-- ----------------------------
BEGIN;
INSERT INTO `T_BLOG_TAG` VALUES ('1', 'ddd', '136'), ('2', 'kkk', '136'), ('3', 'a', '136');
COMMIT;

-- ----------------------------
--  Table structure for `T_BRIDGE_CHAT`
-- ----------------------------
DROP TABLE IF EXISTS `T_BRIDGE_CHAT`;
CREATE TABLE `T_BRIDGE_CHAT` (
  `ID` int(22) NOT NULL,
  `DATA` varchar(1000) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `ID` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
--  Records of `T_BRIDGE_CHAT`
-- ----------------------------
BEGIN;
INSERT INTO `T_BRIDGE_CHAT` VALUES ('1', '你妹啊[笑崩]'), ('2', '哈哈'), ('3', '哈哈'), ('4', '呃呃'), ('5', '[大哭][大哭][羞]'), ('6', '(⊙o⊙)看电视呢'), ('7', '[墨镜]'), ('8', '[怒]'), ('9', '想你了'), ('10', '抵制日货'), ('11', '哈哈哈'), ('12', '哈哈哈哈哈哈哈'), ('13', '哈哈哈哈o(≧v≦)o'), ('14', '[微笑][墨镜]'), ('15', '不错'), ('16', '必须的'), ('17', '[墨镜][发呆]'), ('18', '[墨镜]那你看看'), ('19', '[发呆][发呆][发呆][墨镜]'), ('20', '[发呆][美女]哈哈哈哈哈哈哈'), ('21', '[坏笑]哈哈哈哈哈哈哈'), ('22', '吧'), ('23', '里'), ('24', '我回来的人偶遇'), ('25', '为啥啦啊[美女]啦啦[发呆][发呆]'), ('26', '哈哈哈，[微笑][微笑]'), ('27', 'g[墨镜]4好吧[发呆][伤心]'), ('28', '[发呆][发呆][大哭]'), ('29', '[微笑]哦哦'), ('30', '[发呆]'), ('31', '[微笑]'), ('32', '[笑崩]'), ('33', '啦啦啦'), ('34', '呃呃呃额额[墨镜]'), ('35', '屌爆了'), ('36', '[怒]'), ('37', '哈哈o(≧v≦)o'), ('38', '[美女]'), ('39', '哈哈哈'), ('40', '哈哈哈哈哈哈哈'), ('41', '看看'), ('42', '基金什么?_?'), ('43', '123456[快乐]'), ('44', '[微笑[微笑]微笑'), ('49', '你是?_?'), ('50', 'hao'), ('57', '[惊恐][惊恐]'), ('64', '第一次发送，请接收'), ('65', '第二次发送，请接收，完毕'), ('71', '第一次发送，请接收'), ('72', '第二次发送，请接收，完毕');
COMMIT;

-- ----------------------------
--  Table structure for `T_BRIDGE_COMMON`
-- ----------------------------
DROP TABLE IF EXISTS `T_BRIDGE_COMMON`;
CREATE TABLE `T_BRIDGE_COMMON` (
  `ID` int(22) NOT NULL AUTO_INCREMENT,
  `UUID` varchar(50) DEFAULT NULL,
  `FROM_USERNAME` varchar(200) DEFAULT NULL,
  `TO_USERNAME` varchar(200) DEFAULT NULL,
  `TYPE` int(1) DEFAULT NULL,
  `STATUS` int(1) DEFAULT '0',
  `CREATE_TIME` datetime DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `STATUS` (`STATUS`)
) ENGINE=InnoDB AUTO_INCREMENT=73 DEFAULT CHARSET=utf8;

-- ----------------------------
--  Records of `T_BRIDGE_COMMON`
-- ----------------------------
BEGIN;
INSERT INTO `T_BRIDGE_COMMON` VALUES ('1', '27d723dd-7022-4f26-a08d-e8a8def89504', 'lix', '13718922561', '0', '1', '2014-12-06 20:12:55'), ('2', 'd83614e3-8d3c-40e5-9353-205d4161c2f8', 'lix', '13718922561', '0', '1', '2014-12-06 20:13:20'), ('3', 'bef14ac8-fc2f-42d9-b4c4-758f0841a4d2', 'lix', '13718922561', '0', '1', '2014-12-06 20:13:45'), ('4', '851a2dbd-1741-40c0-bdc5-8d094619cb36', '13718922561', 'lix', '0', '1', '2014-12-06 21:32:30'), ('5', '3a8109c3-80e5-4714-9121-80cd4015f0f5', '13718922561', 'lix', '0', '1', '2014-12-06 21:32:42'), ('6', '2f8799dc-66a9-4bbf-a4a6-e07e0731cb78', 'lix', '13718922561', '0', '1', '2014-12-06 22:12:39'), ('7', '0206d6df-be5e-4c89-a428-0c493fde583c', '13718922561', 'lix', '0', '1', '2014-12-06 22:12:52'), ('8', 'cc3e7776-d1b3-42ab-940e-6e4fd9bee82d', 'lix', '13718922561', '0', '1', '2014-12-06 22:13:15'), ('9', '5f0a1f6b-9f42-482a-9eb4-e1c80ca9d2c8', 'lix', '13718922561', '0', '1', '2014-12-06 22:13:24'), ('10', '454e5e20-fcca-45f6-b652-1201b31d12ba', 'lix', '13718922561', '0', '1', '2014-12-06 22:14:07'), ('11', 'bc857ca1-03bd-46a7-b42b-8620d7cef3b9', '13718922561', 'lix', '0', '1', '2014-12-06 22:14:12'), ('12', '5d7bad51-01c2-4202-8a15-d2c126703db5', '13718922561', 'lix', '0', '1', '2014-12-06 22:14:37'), ('13', 'c298300c-cc94-4125-9fb0-6f16ffce02e3', '13718922561', 'lix', '0', '1', '2014-12-06 22:14:51'), ('14', 'be57a392-d5aa-47a5-bdfc-9c49428a876b', 'lix', '13718922561', '0', '1', '2014-12-06 22:15:03'), ('15', 'aee27437-ae69-4c08-8915-c39e232115e9', 'lix', '13718922561', '0', '1', '2014-12-06 22:15:09'), ('16', '3ce77b0c-d746-4a9c-ba42-de137c340017', '13718922561', 'lix', '0', '1', '2014-12-06 22:15:14'), ('17', '4b6b0bb4-ea63-4a42-99bf-a91f1c6b0173', '13718922561', 'lix', '0', '1', '2014-12-06 22:15:18'), ('18', 'e3eac9d2-6590-4c03-9f14-7c800fd090ee', '13718922561', 'lix', '0', '1', '2014-12-06 22:15:28'), ('19', '778dd8d0-3f54-4d7f-a274-81f009022178', '13718922561', 'lix', '0', '1', '2014-12-06 22:15:37'), ('20', '46dddc0e-c8ee-49cc-92e5-b3c6fa0905ac', '13718922561', 'lix', '0', '1', '2014-12-06 22:15:44'), ('21', '945b9ded-d609-4723-b90b-56d4e25cd175', '13718922561', 'lix', '0', '1', '2014-12-06 22:15:52'), ('22', '47de8b65-11ef-44dd-977a-61ff2de3db77', 'lix', '13718922561', '0', '1', '2014-12-06 22:15:57'), ('23', '80b61c78-d6d3-4142-b51a-2569f2965fb0', '13718922561', 'lix', '0', '1', '2014-12-06 22:15:57'), ('24', '3381b512-082d-4521-a2ca-8598dd4f5c8c', 'lix', '13718922561', '0', '1', '2014-12-06 22:16:48'), ('25', '55d2ee0a-a540-427b-9213-75b61a4bf324', '13718922561', 'lix', '0', '1', '2014-12-06 22:17:17'), ('26', '0336c208-4c1e-466e-a68e-5b8f899472e4', 'lix', '13718922561', '0', '1', '2014-12-06 22:17:40'), ('27', '1f03dd92-b24b-45bf-8df4-8353cfb9f437', 'lix', '13718922561', '0', '1', '2014-12-06 22:18:11'), ('28', '0c2fa008-0a35-4d0a-b0cf-3451e1b3b507', '13718922561', 'lix', '0', '1', '2014-12-06 22:18:31'), ('29', 'b1b6648f-6ccf-405d-8cfb-4dda351f23b6', '13718922561', 'lix', '0', '1', '2014-12-06 22:18:39'), ('30', '65c01a69-29ec-4c8f-9fde-b8e79e8dec9b', '13718922561', 'lix', '0', '1', '2014-12-06 22:18:58'), ('31', '209496a4-c127-4f0c-9212-88b109be9626', 'lix', '13718922561', '0', '1', '2014-12-06 22:19:17'), ('32', '393e4db5-6801-45b9-aba0-5564f2b2c5d6', '13718922561', 'lix', '0', '1', '2014-12-06 22:35:41'), ('33', 'ec42420a-e199-4188-8850-c26c1dd4b572', '13718922561', 'lix', '0', '1', '2014-12-06 22:35:46'), ('34', 'ee69733e-6d1b-4555-b819-2026daae42ef', 'lix', '13718922561', '0', '1', '2014-12-06 22:38:03'), ('35', 'f8c35f36-ae02-456d-acb7-053874bdc665', '13718922561', 'lix', '0', '1', '2014-12-06 22:38:29'), ('36', '346da41a-be64-4f3c-967a-7db4e6c093c6', 'lix', '13718922561', '0', '1', '2014-12-06 22:38:31'), ('37', 'ba198aa0-8b4c-43a9-9c37-8b80a37fde7b', '13718922561', 'lix', '0', '1', '2014-12-06 22:38:49'), ('38', 'f21d12f3-7214-46b3-981a-af38507db8e0', '13718922561', 'lix', '0', '1', '2014-12-06 22:38:52'), ('39', 'd04998ce-23b4-48fd-b4fb-42d437a65c6a', '13718922561', 'lix', '0', '1', '2014-12-06 22:38:56'), ('40', 'be13e0ba-8c89-4c4e-a2b9-0a415d98817a', '13718922561', 'lix', '0', '1', '2014-12-06 22:38:58'), ('41', '87b81f66-3317-4551-a761-7660b36cd99a', '13718922561', 'lix', '0', '1', '2014-12-06 22:39:31'), ('42', '03a65710-fdf8-4a50-b5de-5444a9f2f361', 'lix', '13718922561', '0', '1', '2014-12-07 20:10:07'), ('43', '4421e1f6-14e2-4924-b2ea-3de599c778a8', '13718922561', 'lix', '0', '1', '2014-12-07 20:10:23'), ('44', '673c58a1-cea6-43a9-9c45-ce56932ae6cb', 'lix', '13718922561', '0', '1', '2014-12-07 20:25:53'), ('45', '715f2888-3385-4136-9f13-a9c883f6de24_3', 'lix', '13718922561', '1', '1', '2014-12-20 18:13:58'), ('46', 'f611854e-9eb5-4253-aeca-cdb868eedaa6_5', '13718922561', 'lix', '1', '1', '2014-12-20 18:20:29'), ('47', '1b3a009a-ab8b-4d84-86d3-072e379744fd_3', 'lix', '13718922561', '1', '1', '2014-12-20 18:20:45'), ('48', 'e724311f-4516-4817-9053-b05dad268e8b_4', 'lix', '13718922561', '1', '1', '2014-12-20 18:21:45'), ('49', 'd229b7d8-74aa-40d3-8606-c13069228211', '13718922561', 'lix', '0', '1', '2014-12-20 18:22:49'), ('50', '8b81c426-dd60-4d89-b9b5-b59f706a376d', 'lix', '13718922561', '0', '1', '2014-12-20 18:23:10'), ('51', 'b2654dd7-2f98-4ccd-9a35-4fcb5bbf985e_6', '13718922561', 'lix', '1', '1', '2014-12-20 18:23:50'), ('52', '43febb3f-f88d-4946-89fb-f849c6d6be10_13', 'lix', '13718922561', '1', '1', '2014-12-20 18:24:19'), ('53', '8793ec9e-fbcf-4196-a28b-cba502e83173_3', '13718922561', 'lix', '1', '1', '2014-12-20 20:38:19'), ('54', 'fe6e2bb8-8e9e-488e-9029-96e5e6c4c50a_6', 'lix', '13718922561', '1', '1', '2014-12-20 20:38:39'), ('55', 'adf2e5b7-5718-4e82-9fa5-d7a97c13bfbf_6', '13718922561', 'lix', '1', '1', '2014-12-20 21:39:14'), ('56', 'db76591f-7e59-41ad-b13d-ea60905aef16_5', 'lix', '13718922561', '1', '1', '2014-12-20 21:39:38'), ('57', '33588ecd-98c4-4396-9603-70e29718a6e6', 'lix', '13718922561', '0', '1', '2014-12-20 21:40:43'), ('58', '52e9d2a0-6dba-458b-be26-c7ef218c6173_5', 'lix', '13718922561', '1', '1', '2014-12-20 21:49:57'), ('59', 'ffd68f96-7c0d-4767-bfdc-e9d8b37bd301_3', '13718922561', 'lix', '1', '1', '2014-12-20 21:50:39'), ('60', '24550074-47a4-4f0c-b48c-1c596eb07bc6_3', '13718922561', 'lix', '1', '1', '2014-12-20 21:51:05'), ('61', '3219d0ed-da5f-4cd7-8ac0-0487204a4ec8_3', 'lix', '13718922561', '1', '1', '2014-12-20 21:51:41'), ('62', '22f048ff-9a2a-4462-80e7-fbed6cb8eea6_2', '13718922561', 'lix', '1', '1', '2014-12-20 21:53:17'), ('63', 'a48f3484-1bc9-4dbb-a837-829b74785637_2', '13718922561', 'lix', '1', '1', '2014-12-20 21:53:27'), ('64', 'eed8dfaa-612a-4b8a-8610-8d7bbfc4b7a2', 'yangchen', 'test', '0', '1', '2014-12-31 23:11:33'), ('65', '2b23f718-070d-47d0-8a56-41c57ee603a3', 'yangchen', 'test', '0', '1', '2014-12-31 23:11:36'), ('69', '7e37d63c-8252-49fd-993b-134a332618a0', 'yangchen', 'test', '1', '1', '2015-01-01 01:47:14'), ('70', 'f1405f8c-7b82-46ff-8e40-22709fdfd82b', 'yangchen', 'test', '1', '1', '2015-01-01 01:47:14'), ('71', '1f235ac0-3ce4-4fbd-ba38-4c14f22aef05', 'yangchen', 'test', '0', '1', '2015-07-11 14:04:41'), ('72', 'b322165b-676b-4757-8333-6b20dd7e27ab', 'yangchen', 'test', '0', '1', '2015-07-11 14:04:44');
COMMIT;

-- ----------------------------
--  Table structure for `T_BRIDGE_FILE`
-- ----------------------------
DROP TABLE IF EXISTS `T_BRIDGE_FILE`;
CREATE TABLE `T_BRIDGE_FILE` (
  `ID` int(22) NOT NULL,
  `FILE_NAME` varchar(200) DEFAULT NULL,
  `FILE_SIZE` int(22) DEFAULT NULL,
  `FILE_MD5` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `ID` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
--  Records of `T_BRIDGE_FILE`
-- ----------------------------
BEGIN;
INSERT INTO `T_BRIDGE_FILE` VALUES ('45', '715f2888-3385-4136-9f13-a9c883f6de24', '8864', '8406a64267410a7dca6bc0e51d76dc39'), ('46', 'f611854e-9eb5-4253-aeca-cdb868eedaa6', '12736', 'ae34d68b749292c857b03857ddee2440'), ('47', '1b3a009a-ab8b-4d84-86d3-072e379744fd', '8320', 'a45331a4a83ab333fe085f262be3b8b9'), ('48', 'e724311f-4516-4817-9053-b05dad268e8b', '11072', 'cf1b3a3429e88c7a81c73c088dd238be'), ('51', 'b2654dd7-2f98-4ccd-9a35-4fcb5bbf985e', '14400', '44701f2fef340d8d52ab8578e8d3109f'), ('52', '43febb3f-f88d-4946-89fb-f849c6d6be10', '24832', '95168f32f7b7b1fd86e7e5c07e8a12ac'), ('53', '8793ec9e-fbcf-4196-a28b-cba502e83173', '9888', 'cced8da010b9e9b3a0cd88b2e60cdc74'), ('54', 'fe6e2bb8-8e9e-488e-9029-96e5e6c4c50a', '13280', '80b34d355a208935d9c8dd43b521f51f'), ('55', 'adf2e5b7-5718-4e82-9fa5-d7a97c13bfbf', '13152', '1ea463f8645a6ed598f19e8f90ea6847'), ('56', 'db76591f-7e59-41ad-b13d-ea60905aef16', '11552', '08b6ad2372a52ffd431f7f45dffb137c'), ('58', '52e9d2a0-6dba-458b-be26-c7ef218c6173', '12576', '1594cd07f861d3fdb1969a5c6a3b4b9c'), ('59', 'ffd68f96-7c0d-4767-bfdc-e9d8b37bd301', '9280', '3b3d0ac0a07be7070efade0a924b2d47'), ('60', '24550074-47a4-4f0c-b48c-1c596eb07bc6', '9472', '3ed98bb8c194330894538bace5a50cf1'), ('61', '3219d0ed-da5f-4cd7-8ac0-0487204a4ec8', '9632', '14885a591ff020791308e2d91c37d31c'), ('62', '22f048ff-9a2a-4462-80e7-fbed6cb8eea6', '6816', 'd6d214ce0e3614f87807142aaf24a00b'), ('63', 'a48f3484-1bc9-4dbb-a837-829b74785637', '7232', '04aa70951ac9a31c9c5504028212c87c'), ('69', 'apache-tomcat-6.0.35.tar.gz', '6697806', '171d255cd60894b29a41684ce0ff93a8'), ('70', 'BetterZip for Mac 2.3.3.dmg', '11204913', 'dcafe860fc1d193e4cb0ce34ad35f211');
COMMIT;

-- ----------------------------
--  Table structure for `T_SYS_ACL`
-- ----------------------------
DROP TABLE IF EXISTS `T_SYS_ACL`;
CREATE TABLE `T_SYS_ACL` (
  `ID` int(22) NOT NULL AUTO_INCREMENT,
  `ROLE_ID` int(22) DEFAULT NULL,
  `MENU_ID` int(22) DEFAULT NULL,
  `OPERATE_STATUS` int(22) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `ID` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=129 DEFAULT CHARSET=utf8;

-- ----------------------------
--  Records of `T_SYS_ACL`
-- ----------------------------
BEGIN;
INSERT INTO `T_SYS_ACL` VALUES ('37', '30', '13', '15'), ('38', '30', '15', '15'), ('39', '30', '16', '15'), ('40', '30', '14', '11'), ('41', '30', '2', '15'), ('43', '42', '2', '0'), ('44', '42', '13', '0'), ('45', '42', '14', '0'), ('46', '42', '17', '0'), ('53', '30', '1', '15'), ('54', '30', '3', '15'), ('55', '30', '6', '15'), ('56', '30', '7', '15'), ('57', '30', '8', '15'), ('58', '30', '4', '15'), ('59', '30', '9', '15'), ('60', '30', '10', '15'), ('61', '30', '5', '15'), ('62', '30', '11', '15'), ('63', '30', '12', '15'), ('64', '30', '17', '15'), ('65', '30', '29', '15'), ('66', '30', '21', '15'), ('67', '42', '1', '15'), ('68', '42', '3', '15'), ('69', '42', '4', '15'), ('70', '42', '5', '15'), ('71', '42', '6', '15'), ('72', '42', '7', '15'), ('73', '42', '8', '15'), ('74', '42', '9', '15'), ('75', '42', '10', '15'), ('76', '42', '11', '15'), ('77', '42', '12', '15'), ('126', '30', '125', '15'), ('127', '42', '125', '15'), ('128', '30', '127', '15');
COMMIT;

-- ----------------------------
--  Table structure for `T_SYS_DEPARTMENT`
-- ----------------------------
DROP TABLE IF EXISTS `T_SYS_DEPARTMENT`;
CREATE TABLE `T_SYS_DEPARTMENT` (
  `ID` int(22) NOT NULL AUTO_INCREMENT,
  `DEPT_NAME` varchar(200) DEFAULT NULL,
  `SERIAL_NUM` int(22) DEFAULT NULL,
  `CREATE_USER` int(22) DEFAULT NULL,
  `CREATE_TIME` datetime DEFAULT NULL,
  `UPDATE_USER` int(22) DEFAULT NULL,
  `UPDATE_TIME` datetime DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `ID` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;

-- ----------------------------
--  Records of `T_SYS_DEPARTMENT`
-- ----------------------------
BEGIN;
INSERT INTO `T_SYS_DEPARTMENT` VALUES ('1', '研发部', '1', '1', '2012-09-01 17:09:57', null, null), ('2', 'AAA部', '2', '1', '2012-09-08 23:54:42', '1', '2014-05-23 11:35:21'), ('3', 'BBB部', '3', '1', '2012-09-08 23:54:42', null, null), ('4', 'CCC部', '4', '1', '2012-09-08 23:54:42', null, null), ('5', 'DDD部', '5', '1', '2012-09-08 23:54:42', null, null), ('6', 'EEE部', '6', '1', '2012-09-08 23:54:42', null, null), ('7', 'FFF部', '7', '1', '2012-09-08 23:54:42', null, null), ('8', 'GGG部', '8', '1', '2012-09-08 23:54:42', null, null), ('9', 'HHH部', '9', '1', '2012-09-08 23:54:42', null, null), ('10', 'III部', '10', '1', '2012-09-08 23:54:42', null, null), ('11', 'JJJ部', '11', '1', '2012-09-08 23:54:42', null, null), ('12', 'kkk部', '12', '1', '2012-09-08 23:54:42', '1', '2015-06-12 01:27:12'), ('16', '人事部', '22', null, '2012-09-09 14:02:29', '1', '2015-04-26 01:05:29');
COMMIT;

-- ----------------------------
--  Table structure for `T_SYS_MENU`
-- ----------------------------
DROP TABLE IF EXISTS `T_SYS_MENU`;
CREATE TABLE `T_SYS_MENU` (
  `ID` int(22) NOT NULL AUTO_INCREMENT,
  `MENU_NAME` varchar(200) DEFAULT NULL,
  `MENU_ALIAS` varchar(200) DEFAULT NULL,
  `MENU_URL` varchar(200) DEFAULT NULL,
  `PARENT_MENU_ID` int(22) DEFAULT NULL,
  `SERIAL_NUM` int(22) DEFAULT NULL,
  `ISSHOW` int(1) DEFAULT NULL,
  `DESCRIPTION` varchar(200) DEFAULT NULL,
  `CREATE_USER` int(22) DEFAULT NULL,
  `CREATE_TIME` datetime DEFAULT NULL,
  `UPDATE_USER` int(22) DEFAULT NULL,
  `UPDATE_TIME` datetime DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `ID` (`ID`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=128 DEFAULT CHARSET=utf8;

-- ----------------------------
--  Records of `T_SYS_MENU`
-- ----------------------------
BEGIN;
INSERT INTO `T_SYS_MENU` VALUES ('1', '我的应用', null, 'jsp/frame/main.jsp', '0', '1', '1', '我的应用', '1', '2012-09-01 17:15:00', '1', '2014-07-22 18:38:53'), ('2', '系统管理', null, 'jsp/frame/main.jsp', '0', '2', '1', '系统管理', '1', '2012-09-01 17:15:32', null, null), ('3', '博客', null, null, '1', '1', '1', '博客', '1', '2012-09-01 17:36:25', '1', '2014-07-16 18:51:15'), ('4', '消费统计', null, null, '1', '2', '1', '消费统计', '1', '2012-09-01 17:36:25', null, null), ('5', '消费分析', null, null, '1', '3', '1', '消费分析', '1', '2012-09-01 17:36:25', null, null), ('6', '属性信息', 'attr', 'jsp/blog_bg/attr.jsp', '3', '1', '1', '属性信息', '1', '2012-09-01 17:36:25', '1', '2014-07-15 16:00:23'), ('7', '发表文章', 'article', 'jsp/blog_bg/article.jsp', '3', '2', '1', '发表文章', '1', '2012-09-01 17:36:25', '1', '2014-07-21 19:14:47'), ('8', '文章管理', 'category', 'jsp/blog_bg/category.jsp', '3', '3', '1', '文章管理', '1', '2012-09-01 17:36:25', '1', '2014-07-21 19:15:09'), ('9', '日消费统计', null, null, '4', '1', '1', '日消费统计', '1', '2012-09-01 17:38:44', null, null), ('10', '月消费统计', null, null, '4', '2', '1', '月消费统计', '1', '2012-09-01 17:38:44', null, null), ('11', '月消费分析', null, null, '5', '1', '1', '月消费分析', '1', '2012-09-01 17:39:20', null, null), ('12', '年消费分析', null, null, '5', '2', '1', '年消费分析', '1', '2012-09-01 17:39:21', null, null), ('13', '基础信息', null, null, '2', '1', '1', '基础信息', '1', '2012-09-08 22:33:31', null, null), ('14', '部门管理', 'dept', 'jsp/system/dept.jsp', '13', '1', '1', '部门管理', '1', '2012-09-08 22:34:05', '1', '2012-09-10 23:45:55'), ('15', '系统信息', null, null, '2', '2', '1', '系统信息', '1', '2012-09-08 22:39:45', null, null), ('16', '菜单管理', 'menu', 'jsp/system/menu.jsp', '15', '1', '1', '菜单管理', '1', '2012-09-08 22:40:30', '1', '2012-09-10 23:46:41'), ('17', '人员管理', 'person', 'jsp/system/person.jsp', '13', '2', '1', '人员管理', '1', '2012-09-11 00:23:47', '1', '2012-09-15 22:41:10'), ('21', 'aaa', null, 'aaa', '13', '8', '1', 'aaa', '1', '2012-09-11 23:34:04', '1', '2012-09-21 17:05:56'), ('29', '角色管理', 'role', 'jsp/system/role.jsp', '13', '3', '1', '角色管理', '1', '2012-09-21 17:05:41', null, null), ('125', '评论管理', 'comment', 'jsp/blog_bg/comment.jsp', '3', '4', '1', '评论管理', '1', '2014-07-22 18:36:52', null, null), ('126', '系统菜单', null, null, null, '1', '1', '系统菜单', '1', '2012-09-01 17:12:18', null, null), ('127', 'Mina服务', 'bridge', 'jsp/bridge/client.jsp', '15', '2', '1', 'Mina服务', '1', '2014-09-01 22:16:55', null, null);
COMMIT;

-- ----------------------------
--  Table structure for `T_SYS_PERSON`
-- ----------------------------
DROP TABLE IF EXISTS `T_SYS_PERSON`;
CREATE TABLE `T_SYS_PERSON` (
  `ID` int(22) NOT NULL AUTO_INCREMENT,
  `NICKNAME` varchar(50) DEFAULT NULL,
  `SEX` int(1) DEFAULT NULL,
  `PHONE` varchar(50) DEFAULT NULL,
  `SPELL` varchar(100) DEFAULT NULL,
  `PHOTO` varchar(100) DEFAULT NULL,
  `SIGNATURE` varchar(100) DEFAULT NULL,
  `USER_ID` int(22) DEFAULT NULL,
  `DEPT_ID` int(22) DEFAULT NULL,
  `CREATE_USER` int(22) DEFAULT NULL,
  `CREATE_TIME` datetime DEFAULT NULL,
  `UPDATE_USER` int(22) DEFAULT NULL,
  `UPDATE_TIME` datetime DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `ID` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=118 DEFAULT CHARSET=utf8;

-- ----------------------------
--  Records of `T_SYS_PERSON`
-- ----------------------------
BEGIN;
INSERT INTO `T_SYS_PERSON` VALUES ('1', '杨晨', '1', '13718922561', 'yangchen yc', null, null, '1', '1', '1', '2012-09-15 23:19:07', '1', '2012-09-15 23:19:07'), ('22', '朱春生', '1', '15810483900', 'zhuchunsheng zcs', null, null, '23', '1', '1', '2012-09-15 23:02:27', null, null), ('27', '王省', '1', '15652667600', 'wangsheng ws', null, null, '28', '1', '1', '2012-09-17 13:39:49', null, null), ('105', '测试', '0', '13819273268', 'ceshi cs', null, null, '106', '5', '1', '2014-06-26 20:49:23', '1', '2014-07-01 19:43:50'), ('112', '杨晨', '1', '13718922561', 'yangchen yc', '../upload/portrait/113_1414850458106.png', '越来越好', '113', null, null, '2014-10-26 01:02:37', '113', '2015-01-10 23:02:28'), ('113', '超人', '1', null, 'superman superman', null, '维护世界和平', '114', null, null, null, null, null), ('114', '开心果', '0', '18604050641', 'kaixinguo kxg', null, '高贵冷艳的话唠', '115', null, null, null, null, null), ('115', '安卓机器人', '1', null, 'anzhuojiqiren azjqr', null, '绝逼干掉苹果', '116', null, null, null, null, null), ('116', '李想', '1', '13719201923', 'lixiang lx', null, '办理银行各种业务', '117', null, null, null, '117', '2014-12-20 21:37:21'), ('117', '乐高', '0', '19218002911', 'lego lego', null, '世界第一玩具', '118', null, null, null, null, null);
COMMIT;

-- ----------------------------
--  Table structure for `T_SYS_PERSON_REL`
-- ----------------------------
DROP TABLE IF EXISTS `T_SYS_PERSON_REL`;
CREATE TABLE `T_SYS_PERSON_REL` (
  `ID` int(22) NOT NULL,
  `FRIEND_ID` int(22) NOT NULL,
  KEY `ID` (`ID`),
  KEY `FRIEND_ID` (`FRIEND_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
--  Records of `T_SYS_PERSON_REL`
-- ----------------------------
BEGIN;
INSERT INTO `T_SYS_PERSON_REL` VALUES ('113', '1'), ('113', '23'), ('113', '28'), ('113', '106'), ('113', '114'), ('113', '115'), ('113', '116'), ('113', '117'), ('113', '118'), ('117', '116'), ('117', '114'), ('117', '113');
COMMIT;

-- ----------------------------
--  Table structure for `T_SYS_ROLE`
-- ----------------------------
DROP TABLE IF EXISTS `T_SYS_ROLE`;
CREATE TABLE `T_SYS_ROLE` (
  `ID` int(22) NOT NULL AUTO_INCREMENT,
  `ROLE_NAME` varchar(200) DEFAULT NULL,
  `CREATE_USER` int(22) DEFAULT NULL,
  `CREATE_TIME` datetime DEFAULT NULL,
  `UPDATE_USER` int(22) DEFAULT NULL,
  `UPDATE_TIME` datetime DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `ID` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8;

-- ----------------------------
--  Records of `T_SYS_ROLE`
-- ----------------------------
BEGIN;
INSERT INTO `T_SYS_ROLE` VALUES ('30', '系统管理员', '1', '2012-09-21 17:52:28', null, null), ('42', '普通用户', '1', '2012-09-26 14:13:38', null, null);
COMMIT;

-- ----------------------------
--  Table structure for `T_SYS_USER`
-- ----------------------------
DROP TABLE IF EXISTS `T_SYS_USER`;
CREATE TABLE `T_SYS_USER` (
  `ID` int(22) NOT NULL AUTO_INCREMENT,
  `USERNAME` varchar(200) DEFAULT NULL,
  `PASSWORD` varchar(200) DEFAULT NULL,
  `CREATE_USER` int(22) DEFAULT NULL,
  `CREATE_TIME` datetime DEFAULT NULL,
  `UPDATE_USER` int(22) DEFAULT NULL,
  `UPDATE_TIME` datetime DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `ID` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=119 DEFAULT CHARSET=utf8;

-- ----------------------------
--  Records of `T_SYS_USER`
-- ----------------------------
BEGIN;
INSERT INTO `T_SYS_USER` VALUES ('1', 'yangchen', '28c8edde3d61a0411511d3b1866f0636', '1', '2012-09-01 17:08:27', '1', '2012-09-15 23:19:07'), ('23', 'zhuchunsheng', '14e1b600b1fd579f47433b88e8d85291', '1', '2012-09-15 23:02:27', null, null), ('28', 'wangsheng', '14e1b600b1fd579f47433b88e8d85291', '1', '2012-09-17 13:39:49', null, null), ('106', 'test', '14e1b600b1fd579f47433b88e8d85291', '1', '2014-06-26 20:49:23', '1', '2014-07-01 19:43:50'), ('113', '13718922561', '14e1b600b1fd579f47433b88e8d85291', null, '2014-10-26 01:02:37', null, null), ('114', 'superman', '14e1b600b1fd579f47433b88e8d85291', null, '2014-11-16 01:27:07', null, null), ('115', 'wife', '14e1b600b1fd579f47433b88e8d85291', null, '2014-11-16 01:27:11', null, null), ('116', 'android', '14e1b600b1fd579f47433b88e8d85291', null, '2014-11-16 01:27:16', null, null), ('117', 'lix', '14e1b600b1fd579f47433b88e8d85291', null, '2014-11-16 01:27:19', null, null), ('118', 'lego', '14e1b600b1fd579f47433b88e8d85291', null, '2014-11-16 01:27:22', null, null);
COMMIT;

-- ----------------------------
--  Table structure for `T_SYS_USERSROLES`
-- ----------------------------
DROP TABLE IF EXISTS `T_SYS_USERSROLES`;
CREATE TABLE `T_SYS_USERSROLES` (
  `ID` int(22) NOT NULL AUTO_INCREMENT,
  `USER_ID` int(22) DEFAULT NULL,
  `ROLE_ID` int(22) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `ID` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=110 DEFAULT CHARSET=utf8;

-- ----------------------------
--  Records of `T_SYS_USERSROLES`
-- ----------------------------
BEGIN;
INSERT INTO `T_SYS_USERSROLES` VALUES ('47', '1', '30'), ('48', '1', '42'), ('51', '23', '42'), ('52', '28', '42'), ('109', '106', '42');
COMMIT;

-- ----------------------------
--  Procedure structure for `START_WITH_CONNECT_BY`
-- ----------------------------
DROP PROCEDURE IF EXISTS `START_WITH_CONNECT_BY`;
delimiter ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `START_WITH_CONNECT_BY`(IN  V_TABLE VARCHAR(100), IN  V_START_WITH INT, IN  V_PRIOR_FIELD VARCHAR(100),
                                         IN  V_FIELD VARCHAR(100), OUT V_RESULT VARCHAR(4000))
BEGIN
    SET V_RESULT = '$';
    SET @TEMP    = CAST(V_START_WITH AS CHAR);
    SET @V_SQL   = CONCAT('SELECT GROUP_CONCAT(', V_FIELD, ') INTO @TEMP FROM ', V_TABLE, ' WHERE FIND_IN_SET(', V_PRIOR_FIELD, ', @TEMP) > 0');

    WHILE @TEMP IS NOT NULL
    DO
      SET V_RESULT = CONCAT(V_RESULT, ',', @TEMP);

      PREPARE STMT FROM @V_SQL;
      EXECUTE STMT;
      DEALLOCATE PREPARE STMT;
    END WHILE;
  END
 ;;
delimiter ;

-- ----------------------------
--  Function structure for `START_WITH_PRIOR_CATEGORY`
-- ----------------------------
DROP FUNCTION IF EXISTS `START_WITH_PRIOR_CATEGORY`;
delimiter ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `START_WITH_PRIOR_CATEGORY`(PARENT_ID INT) RETURNS varchar(4000) CHARSET utf8
BEGIN
    DECLARE RESULT VARCHAR(4000);
    DECLARE TEMP   VARCHAR(4000);

    SET RESULT = '$';
    SET TEMP   = CAST(PARENT_ID AS CHAR);

    WHILE TEMP IS NOT NULL
    DO
      SET RESULT = CONCAT(RESULT, ',', TEMP);

      SELECT GROUP_CONCAT(ID)
      INTO   TEMP
      FROM   T_BLOG_CATEGORY
      WHERE  FIND_IN_SET(PARENT_CATEGORY_ID, TEMP) > 0;
    END WHILE;

    RETURN RESULT;
  END
 ;;
delimiter ;

-- ----------------------------
--  Function structure for `START_WITH_PRIOR_MENU`
-- ----------------------------
DROP FUNCTION IF EXISTS `START_WITH_PRIOR_MENU`;
delimiter ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `START_WITH_PRIOR_MENU`(PARENT_ID INT) RETURNS varchar(4000) CHARSET utf8
BEGIN
    DECLARE RESULT VARCHAR(4000);
    DECLARE TEMP   VARCHAR(4000);

    SET RESULT = '$';
    SET TEMP   = CAST(PARENT_ID AS CHAR);

    WHILE TEMP IS NOT NULL
    DO
      SET RESULT = CONCAT(RESULT, ',', TEMP);

      SELECT GROUP_CONCAT(ID)
      INTO   TEMP
      FROM   T_SYS_MENU
      WHERE  FIND_IN_SET(PARENT_MENU_ID, TEMP) > 0;
    END WHILE;

    RETURN RESULT;
  END
 ;;
delimiter ;

-- ----------------------------
--  Function structure for `START_WITH_PRIOR_PARENT_CATEGORY`
-- ----------------------------
DROP FUNCTION IF EXISTS `START_WITH_PRIOR_PARENT_CATEGORY`;
delimiter ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `START_WITH_PRIOR_PARENT_CATEGORY`(CHILD_ID INT) RETURNS varchar(4000) CHARSET utf8
BEGIN
    DECLARE RESULT VARCHAR(4000);
    DECLARE TEMP   VARCHAR(4000);

    SET RESULT = '$';
    SET TEMP   = CAST(CHILD_ID AS CHAR);

    WHILE TEMP IS NOT NULL
    DO
      SET RESULT = CONCAT(RESULT, ',', TEMP);

      SELECT GROUP_CONCAT(PARENT_CATEGORY_ID)
      INTO   TEMP
      FROM   T_BLOG_CATEGORY
      WHERE  FIND_IN_SET(ID, TEMP) > 0;
    END WHILE;

    RETURN RESULT;
  END
 ;;
delimiter ;

-- ----------------------------
--  Function structure for `START_WITH_PRIOR_PARENT_MENU`
-- ----------------------------
DROP FUNCTION IF EXISTS `START_WITH_PRIOR_PARENT_MENU`;
delimiter ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `START_WITH_PRIOR_PARENT_MENU`(CHILD_ID INT) RETURNS varchar(4000) CHARSET utf8
BEGIN
    DECLARE RESULT VARCHAR(4000);
    DECLARE TEMP   VARCHAR(4000);

    SET RESULT = '$';
    SET TEMP   = CAST(CHILD_ID AS CHAR);

    WHILE TEMP IS NOT NULL
    DO
      SET RESULT = CONCAT(RESULT, ',', TEMP);

      SELECT GROUP_CONCAT(PARENT_MENU_ID)
      INTO   TEMP
      FROM   T_SYS_MENU
      WHERE  FIND_IN_SET(ID, TEMP) > 0;
    END WHILE;

    RETURN RESULT;
  END
 ;;
delimiter ;

SET FOREIGN_KEY_CHECKS = 1;
