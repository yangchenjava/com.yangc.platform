/*
Navicat MySQL Data Transfer

Source Server         : localhost
Source Server Version : 50520
Source Host           : localhost:3306
Source Database       : blog

Target Server Type    : MYSQL
Target Server Version : 50520
File Encoding         : 65001

Date: 2014-08-12 14:16:10
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `T_BLOG_ARTICLE`
-- ----------------------------
DROP TABLE IF EXISTS `T_BLOG_ARTICLE`;
CREATE TABLE `T_BLOG_ARTICLE` (
  `ID` int(22) NOT NULL AUTO_INCREMENT,
  `TITLE` varchar(200) DEFAULT NULL,
  `CONTENT` longtext,
  `CATEGORY_ID` int(22) DEFAULT NULL,
  `READ_COUNT` int(22) DEFAULT NULL,
  `CREATE_USER` int(22) DEFAULT NULL,
  `CREATE_TIME` datetime DEFAULT NULL,
  `UPDATE_USER` int(22) DEFAULT NULL,
  `UPDATE_TIME` datetime DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `ID` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=146 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of T_BLOG_ARTICLE
-- ----------------------------
INSERT INTO `T_BLOG_ARTICLE` VALUES ('136', 'JVM_体系结构', '<p style=\"text-align:center\"><img src=\"/../upload/image/20140731/1406803467993030229.jpeg\" title=\"1406803467993030229.jpeg\" alt=\"2012050808411063.jpeg\"/></p><p style=\"font-family: 微软雅黑; font-size: 14px; white-space: normal;\">下面先对图中各部分做个简单的说明：</p><p style=\"font-family: 微软雅黑; font-size: 14px; white-space: normal;\">1.class文件：虚拟机并不关心Class的来源是什么语言，只要它符合Java class文件格式就可以在Java虚拟机中运行。使用Java编译器可以把Java代码编译为存储字节码的Class文件，使用JRuby等其他语言的编译器一样可以把程序代码编译成Class文件。</p><p style=\"font-family: 微软雅黑; font-size: 14px; white-space: normal;\">2.类装载器子系统：负责查找并装载Class 文件到内存，最终形成可以被虚拟机直接使用的Java类型。</p><p style=\"font-family: 微软雅黑; font-size: 14px; white-space: normal;\">3.方法区：在类装载器加载class文件到内存的过程中，虚拟机会提取其中的类型信息，并将这些信息存储到方法区。方法区用于存储已被虚拟机加载的类信息、常量、静态变量、即时编译器编译后的代码等数据。由于所有线程都共享方法区，因此它们对方法区数据的访问必须被设计为是线程安全的。</p><p style=\"font-family: 微软雅黑; font-size: 14px; white-space: normal;\">4.堆：存储Java程序创建的类实例。所有线程共享，因此设计程序时也要考虑到多线程访问对象(堆数据)的同步问题。</p><p style=\"font-family: 微软雅黑; font-size: 14px; white-space: normal;\">5.Java栈：Java栈是线程私有的。每当启动一个新线程时，Java虚拟机都会为它分配一个Java栈。Java栈以帧为单位保存线程的运行状态。虚拟机只会直接对Java栈执行两种操作：以帧为单位的压栈或出栈。当线程调用java方法时，虚拟机压入一个新的栈帧到该线程的java栈中。当方法返回时，这个栈帧被从java栈中弹出并抛弃。一个栈帧包含一个java方法的调用状态，它存储有局部变量表、操作栈、动态链接、方法出口等信息。</p><p style=\"font-family: 微软雅黑; font-size: 14px; white-space: normal;\">&nbsp;6.程序计数器：一个运行中的Java程序，每当启动一个新线程时，都会为这个新线程创建一个自己的PC(程序计数器)寄存器。程序计数器的作用可以看做是当前线程所执行的字节码的行号指示器。字节码解释器工作时就是通过改变这个计数器的值来选取下一条需要执行的字节码指令，分支、循环、跳转、异常处理、线程恢复等基础功能都需要依赖这个计数器来完成。如果线程正在执行的是一个Java方法，这个计数器记录的是正在执行的虚拟机字节码指令的地址；如果正在执行的是Natvie方法，这个计数器值则为空(Undefined)。</p><p style=\"font-family: 微软雅黑; font-size: 14px; white-space: normal;\">7.本地方法栈：本地方法栈与虚拟机栈所发挥的作用是非常相似的，其区别不过是虚拟机栈为虚拟机执行Java方法（也就是字节码）服务，而本地方法栈则是为虚拟机使用到的Native方法服务。任何本地方法接口都会使用某种本地方法栈。当线程调用Java方法时，虚拟机会创建一个新的栈帧并压入Java栈。然而当它调用的是本地方法时，虚拟机会保持Java栈不变，不再在线程的Java栈中压入新的帧，虚拟机只是简单地动态链接并直接调用指定的本地方法。如果某个虚拟机实现的本地方法接口是使用C连接模型的话，那么它的本地方法栈就是C栈。</p><p style=\"font-family: 微软雅黑; font-size: 14px; white-space: normal;\">8.执行引擎：负责执行字节码。方法的字节码是由Java虚拟机的指令序列构成的。每一条指令包含一个单字节的操作码，后面跟随0个或多个操作数。执行引擎执行字节码时，首先取得一个操作码，如果操作码有操作数，取得它的操作数。它执行操作码和跟随的操作数规定的动作，然后再取得下一个操作码。这个执行字节码的过程在线程完成前将一直持续。</p><p><br/></p>', '112', '114', '1', '2014-07-31 18:50:19', null, null);
INSERT INTO `T_BLOG_ARTICLE` VALUES ('145', 'test', '<p>test</p><p>df</p><p>sdfs</p><p>sdfsf</p>', '116', '0', '1', '2014-08-01 13:52:52', null, null);

-- ----------------------------
-- Table structure for `T_BLOG_ATTR`
-- ----------------------------
DROP TABLE IF EXISTS `T_BLOG_ATTR`;
CREATE TABLE `T_BLOG_ATTR` (
  `ID` int(22) NOT NULL AUTO_INCREMENT,
  `ATTR_NAME` varchar(200) DEFAULT NULL,
  `ATTR_VALUE` varchar(200) DEFAULT NULL,
  `DESCRIPTION` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `ID` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=136 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of T_BLOG_ATTR
-- ----------------------------
INSERT INTO `T_BLOG_ATTR` VALUES ('110', 'nickname', '烤馍', '昵称');
INSERT INTO `T_BLOG_ATTR` VALUES ('133', 'qq', '511636835', 'QQ');
INSERT INTO `T_BLOG_ATTR` VALUES ('134', 'github', 'yangchenjava', 'GitHub');
INSERT INTO `T_BLOG_ATTR` VALUES ('135', 'email', 'yangchen_java@126.com', '邮箱');

-- ----------------------------
-- Table structure for `T_BLOG_CATEGORY`
-- ----------------------------
DROP TABLE IF EXISTS `T_BLOG_CATEGORY`;
CREATE TABLE `T_BLOG_CATEGORY` (
  `ID` int(22) NOT NULL AUTO_INCREMENT,
  `CATEGORY_NAME` varchar(200) DEFAULT NULL,
  `PARENT_CATEGORY_ID` int(22) DEFAULT NULL,
  `SERIAL_NUM` int(22) DEFAULT NULL,
  `CREATE_USER` int(22) DEFAULT NULL,
  `CREATE_TIME` datetime DEFAULT NULL,
  `UPDATE_USER` int(22) DEFAULT NULL,
  `UPDATE_TIME` datetime DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `ID` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=118 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of T_BLOG_CATEGORY
-- ----------------------------
INSERT INTO `T_BLOG_CATEGORY` VALUES ('0', '文章类别', null, '1', '1', '2014-07-17 00:00:00', null, null);
INSERT INTO `T_BLOG_CATEGORY` VALUES ('112', 'Java', '0', '1', '1', '2014-07-18 15:31:17', null, null);
INSERT INTO `T_BLOG_CATEGORY` VALUES ('113', '前端', '0', '2', '1', '2014-07-18 15:36:09', null, null);
INSERT INTO `T_BLOG_CATEGORY` VALUES ('114', '缓存', '0', '3', '1', '2014-07-18 15:39:54', null, null);
INSERT INTO `T_BLOG_CATEGORY` VALUES ('115', 'JS', '113', '1', '1', '2014-07-18 15:40:44', null, null);
INSERT INTO `T_BLOG_CATEGORY` VALUES ('116', 'Jquery', '113', '2', '1', '2014-07-18 15:50:22', null, null);
INSERT INTO `T_BLOG_CATEGORY` VALUES ('117', 'ExtJS', '113', '3', '1', '2014-07-18 15:50:48', null, null);

-- ----------------------------
-- Table structure for `T_BLOG_COMMENT`
-- ----------------------------
DROP TABLE IF EXISTS `T_BLOG_COMMENT`;
CREATE TABLE `T_BLOG_COMMENT` (
  `ID` int(22) NOT NULL AUTO_INCREMENT,
  `NAME` varchar(200) DEFAULT NULL,
  `CONTENT` varchar(1000) DEFAULT NULL,
  `ARTICLE_ID` int(22) DEFAULT NULL,
  `IP_ADDRESS` varchar(200) DEFAULT NULL,
  `CREATE_TIME` datetime DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `ID` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=148 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of T_BLOG_COMMENT
-- ----------------------------
INSERT INTO `T_BLOG_COMMENT` VALUES ('146', 'yangc', '还不错，可以理解，评论文字的颜色清晰些就更好了。。。', '136', '127.0.0.1', '2014-08-04 19:12:50');
INSERT INTO `T_BLOG_COMMENT` VALUES ('147', 'jeckson', '@yangc 我也是这么认为', '136', '127.0.0.1', '2014-08-04 19:15:38');

-- ----------------------------
-- Table structure for `T_BLOG_TAG`
-- ----------------------------
DROP TABLE IF EXISTS `T_BLOG_TAG`;
CREATE TABLE `T_BLOG_TAG` (
  `ID` int(22) NOT NULL AUTO_INCREMENT,
  `TAG_NAME` varchar(200) DEFAULT NULL,
  `ARTICLE_ID` int(22) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `ID` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of T_BLOG_TAG
-- ----------------------------
INSERT INTO `T_BLOG_TAG` VALUES ('1', 'ddd', '136');
INSERT INTO `T_BLOG_TAG` VALUES ('2', 'kkk', '136');
INSERT INTO `T_BLOG_TAG` VALUES ('3', 'a', '136');

-- ----------------------------
-- Table structure for `T_SYS_ACL`
-- ----------------------------
DROP TABLE IF EXISTS `T_SYS_ACL`;
CREATE TABLE `T_SYS_ACL` (
  `ID` int(22) NOT NULL AUTO_INCREMENT,
  `ROLE_ID` int(22) DEFAULT NULL,
  `MENU_ID` int(22) DEFAULT NULL,
  `OPERATE_STATUS` int(22) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `ID` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=128 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of T_SYS_ACL
-- ----------------------------
INSERT INTO `T_SYS_ACL` VALUES ('37', '30', '13', '15');
INSERT INTO `T_SYS_ACL` VALUES ('38', '30', '15', '15');
INSERT INTO `T_SYS_ACL` VALUES ('39', '30', '16', '15');
INSERT INTO `T_SYS_ACL` VALUES ('40', '30', '14', '11');
INSERT INTO `T_SYS_ACL` VALUES ('41', '30', '2', '15');
INSERT INTO `T_SYS_ACL` VALUES ('43', '42', '2', '0');
INSERT INTO `T_SYS_ACL` VALUES ('44', '42', '13', '0');
INSERT INTO `T_SYS_ACL` VALUES ('45', '42', '14', '0');
INSERT INTO `T_SYS_ACL` VALUES ('46', '42', '17', '0');
INSERT INTO `T_SYS_ACL` VALUES ('53', '30', '1', '15');
INSERT INTO `T_SYS_ACL` VALUES ('54', '30', '3', '15');
INSERT INTO `T_SYS_ACL` VALUES ('55', '30', '6', '15');
INSERT INTO `T_SYS_ACL` VALUES ('56', '30', '7', '15');
INSERT INTO `T_SYS_ACL` VALUES ('57', '30', '8', '15');
INSERT INTO `T_SYS_ACL` VALUES ('58', '30', '4', '15');
INSERT INTO `T_SYS_ACL` VALUES ('59', '30', '9', '15');
INSERT INTO `T_SYS_ACL` VALUES ('60', '30', '10', '15');
INSERT INTO `T_SYS_ACL` VALUES ('61', '30', '5', '15');
INSERT INTO `T_SYS_ACL` VALUES ('62', '30', '11', '15');
INSERT INTO `T_SYS_ACL` VALUES ('63', '30', '12', '15');
INSERT INTO `T_SYS_ACL` VALUES ('64', '30', '17', '15');
INSERT INTO `T_SYS_ACL` VALUES ('65', '30', '29', '15');
INSERT INTO `T_SYS_ACL` VALUES ('66', '30', '21', '15');
INSERT INTO `T_SYS_ACL` VALUES ('67', '42', '1', '15');
INSERT INTO `T_SYS_ACL` VALUES ('68', '42', '3', '15');
INSERT INTO `T_SYS_ACL` VALUES ('69', '42', '4', '15');
INSERT INTO `T_SYS_ACL` VALUES ('70', '42', '5', '15');
INSERT INTO `T_SYS_ACL` VALUES ('71', '42', '6', '15');
INSERT INTO `T_SYS_ACL` VALUES ('72', '42', '7', '15');
INSERT INTO `T_SYS_ACL` VALUES ('73', '42', '8', '15');
INSERT INTO `T_SYS_ACL` VALUES ('74', '42', '9', '15');
INSERT INTO `T_SYS_ACL` VALUES ('75', '42', '10', '15');
INSERT INTO `T_SYS_ACL` VALUES ('76', '42', '11', '15');
INSERT INTO `T_SYS_ACL` VALUES ('77', '42', '12', '15');
INSERT INTO `T_SYS_ACL` VALUES ('126', '30', '125', '15');
INSERT INTO `T_SYS_ACL` VALUES ('127', '42', '125', '15');

-- ----------------------------
-- Table structure for `T_SYS_DEPARTMENT`
-- ----------------------------
DROP TABLE IF EXISTS `T_SYS_DEPARTMENT`;
CREATE TABLE `T_SYS_DEPARTMENT` (
  `ID` int(22) NOT NULL AUTO_INCREMENT,
  `DEPT_NAME` varchar(200) DEFAULT NULL,
  `SERIAL_NUM` int(22) DEFAULT NULL,
  `CREATE_USER` int(22) DEFAULT NULL,
  `CREATE_TIME` datetime DEFAULT NULL,
  `UPDATE_USER` int(22) DEFAULT NULL,
  `UPDATE_TIME` datetime DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `ID` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of T_SYS_DEPARTMENT
-- ----------------------------
INSERT INTO `T_SYS_DEPARTMENT` VALUES ('1', '研发部', '1', '1', '2012-09-01 17:09:57', null, null);
INSERT INTO `T_SYS_DEPARTMENT` VALUES ('2', 'AAA部', '2', '1', '2012-09-08 23:54:42', '1', '2014-05-23 11:35:21');
INSERT INTO `T_SYS_DEPARTMENT` VALUES ('3', 'BBB部', '3', '1', '2012-09-08 23:54:42', null, null);
INSERT INTO `T_SYS_DEPARTMENT` VALUES ('4', 'CCC部', '4', '1', '2012-09-08 23:54:42', null, null);
INSERT INTO `T_SYS_DEPARTMENT` VALUES ('5', 'DDD部', '5', '1', '2012-09-08 23:54:42', null, null);
INSERT INTO `T_SYS_DEPARTMENT` VALUES ('6', 'EEE部', '6', '1', '2012-09-08 23:54:42', null, null);
INSERT INTO `T_SYS_DEPARTMENT` VALUES ('7', 'FFF部', '7', '1', '2012-09-08 23:54:42', null, null);
INSERT INTO `T_SYS_DEPARTMENT` VALUES ('8', 'GGG部', '8', '1', '2012-09-08 23:54:42', null, null);
INSERT INTO `T_SYS_DEPARTMENT` VALUES ('9', 'HHH部', '9', '1', '2012-09-08 23:54:42', null, null);
INSERT INTO `T_SYS_DEPARTMENT` VALUES ('10', 'III部', '10', '1', '2012-09-08 23:54:42', null, null);
INSERT INTO `T_SYS_DEPARTMENT` VALUES ('11', 'JJJ部', '11', '1', '2012-09-08 23:54:42', null, null);
INSERT INTO `T_SYS_DEPARTMENT` VALUES ('12', 'KKK部', '12', '1', '2012-09-08 23:54:42', null, null);
INSERT INTO `T_SYS_DEPARTMENT` VALUES ('16', '人事部', '22', null, '2012-09-09 14:02:29', '1', '2012-09-09 14:02:42');

-- ----------------------------
-- Table structure for `T_SYS_MENU`
-- ----------------------------
DROP TABLE IF EXISTS `T_SYS_MENU`;
CREATE TABLE `T_SYS_MENU` (
  `ID` int(22) NOT NULL AUTO_INCREMENT,
  `MENU_NAME` varchar(200) DEFAULT NULL,
  `MENU_ALIAS` varchar(200) DEFAULT NULL,
  `MENU_URL` varchar(200) DEFAULT NULL,
  `PARENT_MENU_ID` int(22) DEFAULT NULL,
  `SERIAL_NUM` int(22) DEFAULT NULL,
  `ISSHOW` int(1) DEFAULT NULL,
  `DESCRIPTION` varchar(200) DEFAULT NULL,
  `CREATE_USER` int(22) DEFAULT NULL,
  `CREATE_TIME` datetime DEFAULT NULL,
  `UPDATE_USER` int(22) DEFAULT NULL,
  `UPDATE_TIME` datetime DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `ID` (`ID`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=126 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of T_SYS_MENU
-- ----------------------------
INSERT INTO `T_SYS_MENU` VALUES ('0', '系统菜单', null, null, null, '1', '1', '系统菜单', '1', '2012-09-01 17:12:18', null, null);
INSERT INTO `T_SYS_MENU` VALUES ('1', '我的应用', null, 'jsp/frame/main.jsp', '0', '1', '1', '我的应用', '1', '2012-09-01 17:15:00', '1', '2014-07-22 18:38:53');
INSERT INTO `T_SYS_MENU` VALUES ('2', '系统管理', null, 'jsp/frame/main.jsp', '0', '2', '1', '系统管理', '1', '2012-09-01 17:15:32', null, null);
INSERT INTO `T_SYS_MENU` VALUES ('3', '博客', null, null, '1', '1', '1', '博客', '1', '2012-09-01 17:36:25', '1', '2014-07-16 18:51:15');
INSERT INTO `T_SYS_MENU` VALUES ('4', '消费统计', null, null, '1', '2', '1', '消费统计', '1', '2012-09-01 17:36:25', null, null);
INSERT INTO `T_SYS_MENU` VALUES ('5', '消费分析', null, null, '1', '3', '1', '消费分析', '1', '2012-09-01 17:36:25', null, null);
INSERT INTO `T_SYS_MENU` VALUES ('6', '属性信息', 'attr', 'jsp/blog_bg/attr.jsp', '3', '1', '1', '属性信息', '1', '2012-09-01 17:36:25', '1', '2014-07-15 16:00:23');
INSERT INTO `T_SYS_MENU` VALUES ('7', '发表文章', 'article', 'jsp/blog_bg/article.jsp', '3', '2', '1', '发表文章', '1', '2012-09-01 17:36:25', '1', '2014-07-21 19:14:47');
INSERT INTO `T_SYS_MENU` VALUES ('8', '文章管理', 'category', 'jsp/blog_bg/category.jsp', '3', '3', '1', '文章管理', '1', '2012-09-01 17:36:25', '1', '2014-07-21 19:15:09');
INSERT INTO `T_SYS_MENU` VALUES ('9', '日消费统计', null, null, '4', '1', '1', '日消费统计', '1', '2012-09-01 17:38:44', null, null);
INSERT INTO `T_SYS_MENU` VALUES ('10', '月消费统计', null, null, '4', '2', '1', '月消费统计', '1', '2012-09-01 17:38:44', null, null);
INSERT INTO `T_SYS_MENU` VALUES ('11', '月消费分析', null, null, '5', '1', '1', '月消费分析', '1', '2012-09-01 17:39:20', null, null);
INSERT INTO `T_SYS_MENU` VALUES ('12', '年消费分析', null, null, '5', '2', '1', '年消费分析', '1', '2012-09-01 17:39:21', null, null);
INSERT INTO `T_SYS_MENU` VALUES ('13', '基础信息', null, null, '2', '1', '1', '基础信息', '1', '2012-09-08 22:33:31', null, null);
INSERT INTO `T_SYS_MENU` VALUES ('14', '部门管理', 'dept', 'jsp/system/dept.jsp', '13', '1', '1', '部门管理', '1', '2012-09-08 22:34:05', '1', '2012-09-10 23:45:55');
INSERT INTO `T_SYS_MENU` VALUES ('15', '系统信息', null, null, '2', '2', '1', '系统信息', '1', '2012-09-08 22:39:45', null, null);
INSERT INTO `T_SYS_MENU` VALUES ('16', '菜单管理', 'menu', 'jsp/system/menu.jsp', '15', '1', '1', '菜单管理', '1', '2012-09-08 22:40:30', '1', '2012-09-10 23:46:41');
INSERT INTO `T_SYS_MENU` VALUES ('17', '人员管理', 'person', 'jsp/system/person.jsp', '13', '2', '1', '人员管理', '1', '2012-09-11 00:23:47', '1', '2012-09-15 22:41:10');
INSERT INTO `T_SYS_MENU` VALUES ('21', 'aaa', null, 'aaa', '13', '8', '1', 'aaa', '1', '2012-09-11 23:34:04', '1', '2012-09-21 17:05:56');
INSERT INTO `T_SYS_MENU` VALUES ('29', '角色管理', 'role', 'jsp/system/role.jsp', '13', '3', '1', '角色管理', '1', '2012-09-21 17:05:41', null, null);
INSERT INTO `T_SYS_MENU` VALUES ('125', '评论管理', 'comment', 'jsp/blog_bg/comment.jsp', '3', '4', '1', '评论管理', '1', '2014-07-22 18:36:52', null, null);

-- ----------------------------
-- Table structure for `T_SYS_PERSON`
-- ----------------------------
DROP TABLE IF EXISTS `T_SYS_PERSON`;
CREATE TABLE `T_SYS_PERSON` (
  `ID` int(22) NOT NULL AUTO_INCREMENT,
  `NAME` varchar(50) DEFAULT NULL,
  `SEX` int(1) DEFAULT NULL,
  `PHONE` varchar(50) DEFAULT NULL,
  `SPELL` varchar(100) DEFAULT NULL,
  `DEPT_ID` int(22) DEFAULT NULL,
  `CREATE_USER` int(22) DEFAULT NULL,
  `CREATE_TIME` datetime DEFAULT NULL,
  `UPDATE_USER` int(22) DEFAULT NULL,
  `UPDATE_TIME` datetime DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `ID` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=106 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of T_SYS_PERSON
-- ----------------------------
INSERT INTO `T_SYS_PERSON` VALUES ('1', '杨晨', '1', '13718922561', 'yangchen yc', '1', '1', '2012-09-15 23:19:07', '1', '2012-09-15 23:19:07');
INSERT INTO `T_SYS_PERSON` VALUES ('22', '朱春生', '1', '15810483900', 'zhuchunsheng zcs', '1', '1', '2012-09-15 23:02:27', null, null);
INSERT INTO `T_SYS_PERSON` VALUES ('27', '王省', '1', '15652667600', 'wangsheng ws', '1', '1', '2012-09-17 13:39:49', null, null);
INSERT INTO `T_SYS_PERSON` VALUES ('105', '测试', '0', '13819273268', 'ceshi cs', '5', '1', '2014-06-26 20:49:23', '1', '2014-07-01 19:43:50');

-- ----------------------------
-- Table structure for `T_SYS_ROLE`
-- ----------------------------
DROP TABLE IF EXISTS `T_SYS_ROLE`;
CREATE TABLE `T_SYS_ROLE` (
  `ID` int(22) NOT NULL AUTO_INCREMENT,
  `ROLE_NAME` varchar(200) DEFAULT NULL,
  `CREATE_USER` int(22) DEFAULT NULL,
  `CREATE_TIME` datetime DEFAULT NULL,
  `UPDATE_USER` int(22) DEFAULT NULL,
  `UPDATE_TIME` datetime DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `ID` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of T_SYS_ROLE
-- ----------------------------
INSERT INTO `T_SYS_ROLE` VALUES ('30', '系统管理员', '1', '2012-09-21 17:52:28', null, null);
INSERT INTO `T_SYS_ROLE` VALUES ('42', '普通用户', '1', '2012-09-26 14:13:38', null, null);

-- ----------------------------
-- Table structure for `T_SYS_USER`
-- ----------------------------
DROP TABLE IF EXISTS `T_SYS_USER`;
CREATE TABLE `T_SYS_USER` (
  `ID` int(22) NOT NULL AUTO_INCREMENT,
  `USERNAME` varchar(200) DEFAULT NULL,
  `PASSWORD` varchar(200) DEFAULT NULL,
  `PERSON_ID` int(22) DEFAULT NULL,
  `CREATE_USER` int(22) DEFAULT NULL,
  `CREATE_TIME` datetime DEFAULT NULL,
  `UPDATE_USER` int(22) DEFAULT NULL,
  `UPDATE_TIME` datetime DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `ID` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=107 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of T_SYS_USER
-- ----------------------------
INSERT INTO `T_SYS_USER` VALUES ('1', 'yangchen', '28c8edde3d61a0411511d3b1866f0636', '1', '1', '2012-09-01 17:08:27', '1', '2012-09-15 23:19:07');
INSERT INTO `T_SYS_USER` VALUES ('23', 'zhuchunsheng', '14e1b600b1fd579f47433b88e8d85291', '22', '1', '2012-09-15 23:02:27', null, null);
INSERT INTO `T_SYS_USER` VALUES ('28', 'wangsheng', '14e1b600b1fd579f47433b88e8d85291', '27', '1', '2012-09-17 13:39:49', null, null);
INSERT INTO `T_SYS_USER` VALUES ('106', 'test', '14e1b600b1fd579f47433b88e8d85291', '105', '1', '2014-06-26 20:49:23', '1', '2014-07-01 19:43:50');

-- ----------------------------
-- Table structure for `T_SYS_USERSROLES`
-- ----------------------------
DROP TABLE IF EXISTS `T_SYS_USERSROLES`;
CREATE TABLE `T_SYS_USERSROLES` (
  `ID` int(22) NOT NULL AUTO_INCREMENT,
  `USER_ID` int(22) DEFAULT NULL,
  `ROLE_ID` int(22) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `ID` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=110 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of T_SYS_USERSROLES
-- ----------------------------
INSERT INTO `T_SYS_USERSROLES` VALUES ('47', '1', '30');
INSERT INTO `T_SYS_USERSROLES` VALUES ('48', '1', '42');
INSERT INTO `T_SYS_USERSROLES` VALUES ('51', '23', '42');
INSERT INTO `T_SYS_USERSROLES` VALUES ('52', '28', '42');
INSERT INTO `T_SYS_USERSROLES` VALUES ('109', '106', '42');

-- ----------------------------
-- Procedure structure for `START_WITH_CONNECT_BY`
-- ----------------------------
DROP PROCEDURE IF EXISTS `START_WITH_CONNECT_BY`;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `START_WITH_CONNECT_BY`(IN  V_TABLE VARCHAR(100), IN  V_START_WITH INT, IN  V_PRIOR_FIELD VARCHAR(100),
                                         IN  V_FIELD VARCHAR(100), OUT V_RESULT VARCHAR(4000))
BEGIN
    SET V_RESULT = '$';
    SET @TEMP    = CAST(V_START_WITH AS CHAR);
    SET @V_SQL   = CONCAT('SELECT GROUP_CONCAT(', V_FIELD, ') INTO @TEMP FROM ', V_TABLE, ' WHERE FIND_IN_SET(', V_PRIOR_FIELD, ', @TEMP) > 0');

    WHILE @TEMP IS NOT NULL
    DO
      SET V_RESULT = CONCAT(V_RESULT, ',', @TEMP);

      PREPARE STMT FROM @V_SQL;
      EXECUTE STMT;
      DEALLOCATE PREPARE STMT;
    END WHILE;
  END
;;
DELIMITER ;

-- ----------------------------
-- Function structure for `START_WITH_PRIOR_CATEGORY`
-- ----------------------------
DROP FUNCTION IF EXISTS `START_WITH_PRIOR_CATEGORY`;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `START_WITH_PRIOR_CATEGORY`(PARENT_ID INT) RETURNS varchar(4000) CHARSET utf8
BEGIN
    DECLARE RESULT VARCHAR(4000);
    DECLARE TEMP   VARCHAR(4000);

    SET RESULT = '$';
    SET TEMP   = CAST(PARENT_ID AS CHAR);

    WHILE TEMP IS NOT NULL
    DO
      SET RESULT = CONCAT(RESULT, ',', TEMP);

      SELECT GROUP_CONCAT(ID)
      INTO   TEMP
      FROM   T_BLOG_CATEGORY
      WHERE  FIND_IN_SET(PARENT_CATEGORY_ID, TEMP) > 0;
    END WHILE;

    RETURN RESULT;
  END
;;
DELIMITER ;

-- ----------------------------
-- Function structure for `START_WITH_PRIOR_MENU`
-- ----------------------------
DROP FUNCTION IF EXISTS `START_WITH_PRIOR_MENU`;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `START_WITH_PRIOR_MENU`(PARENT_ID INT) RETURNS varchar(4000) CHARSET utf8
BEGIN
    DECLARE RESULT VARCHAR(4000);
    DECLARE TEMP   VARCHAR(4000);

    SET RESULT = '$';
    SET TEMP   = CAST(PARENT_ID AS CHAR);

    WHILE TEMP IS NOT NULL
    DO
      SET RESULT = CONCAT(RESULT, ',', TEMP);

      SELECT GROUP_CONCAT(ID)
      INTO   TEMP
      FROM   T_SYS_MENU
      WHERE  FIND_IN_SET(PARENT_MENU_ID, TEMP) > 0;
    END WHILE;

    RETURN RESULT;
  END
;;
DELIMITER ;

-- ----------------------------
-- Function structure for `START_WITH_PRIOR_PARENT_CATEGORY`
-- ----------------------------
DROP FUNCTION IF EXISTS `START_WITH_PRIOR_PARENT_CATEGORY`;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `START_WITH_PRIOR_PARENT_CATEGORY`(CHILD_ID INT) RETURNS varchar(4000) CHARSET utf8
BEGIN
    DECLARE RESULT VARCHAR(4000);
    DECLARE TEMP   VARCHAR(4000);

    SET RESULT = '$';
    SET TEMP   = CAST(CHILD_ID AS CHAR);

    WHILE TEMP IS NOT NULL
    DO
      SET RESULT = CONCAT(RESULT, ',', TEMP);

      SELECT GROUP_CONCAT(PARENT_CATEGORY_ID)
      INTO   TEMP
      FROM   T_BLOG_CATEGORY
      WHERE  FIND_IN_SET(ID, TEMP) > 0;
    END WHILE;

    RETURN RESULT;
  END
;;
DELIMITER ;

-- ----------------------------
-- Function structure for `START_WITH_PRIOR_PARENT_MENU`
-- ----------------------------
DROP FUNCTION IF EXISTS `START_WITH_PRIOR_PARENT_MENU`;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `START_WITH_PRIOR_PARENT_MENU`(CHILD_ID INT) RETURNS varchar(4000) CHARSET utf8
BEGIN
    DECLARE RESULT VARCHAR(4000);
    DECLARE TEMP   VARCHAR(4000);

    SET RESULT = '$';
    SET TEMP   = CAST(CHILD_ID AS CHAR);

    WHILE TEMP IS NOT NULL
    DO
      SET RESULT = CONCAT(RESULT, ',', TEMP);

      SELECT GROUP_CONCAT(PARENT_MENU_ID)
      INTO   TEMP
      FROM   T_SYS_MENU
      WHERE  FIND_IN_SET(ID, TEMP) > 0;
    END WHILE;

    RETURN RESULT;
  END
;;
DELIMITER ;
