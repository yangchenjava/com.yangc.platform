﻿SET DEFINE OFF;
--SQL Statement which produced this data:
--
--  SELECT * FROM YANGC.T_SYS_MENU;
--
Insert into T_SYS_MENU
   (ID, MENU_NAME, SERIAL_NUM, ISSHOW, DESCRIPTION, 
    CREATE_USER, CREATE_TIME)
 Values
   (0, '系统菜单', 1, 1, '系统菜单', 
    1, TO_DATE('09/01/2012 17:12:18', 'MM/DD/YYYY HH24:MI:SS'));
Insert into T_SYS_MENU
   (ID, MENU_NAME, MENU_URL, PARENT_MENU_ID, SERIAL_NUM, 
    ISSHOW, DESCRIPTION, CREATE_USER, CREATE_TIME)
 Values
   (1, '随手记', 'jsp/frame/main.jsp', 0, 1, 
    1, '随手记', 1, TO_DATE('09/01/2012 17:15:00', 'MM/DD/YYYY HH24:MI:SS'));
Insert into T_SYS_MENU
   (ID, MENU_NAME, MENU_URL, PARENT_MENU_ID, SERIAL_NUM, 
    ISSHOW, DESCRIPTION, CREATE_USER, CREATE_TIME)
 Values
   (2, '系统管理', 'jsp/frame/main.jsp', 0, 2, 
    1, '系统管理', 1, TO_DATE('09/01/2012 17:15:32', 'MM/DD/YYYY HH24:MI:SS'));
Insert into T_SYS_MENU
   (ID, MENU_NAME, PARENT_MENU_ID, SERIAL_NUM, ISSHOW, 
    DESCRIPTION, CREATE_USER, CREATE_TIME)
 Values
   (3, '消费管理', 1, 1, 1, 
    '消费管理', 1, TO_DATE('09/01/2012 17:36:25', 'MM/DD/YYYY HH24:MI:SS'));
Insert into T_SYS_MENU
   (ID, MENU_NAME, PARENT_MENU_ID, SERIAL_NUM, ISSHOW, 
    DESCRIPTION, CREATE_USER, CREATE_TIME)
 Values
   (4, '消费统计', 1, 2, 1, 
    '消费统计', 1, TO_DATE('09/01/2012 17:36:25', 'MM/DD/YYYY HH24:MI:SS'));
Insert into T_SYS_MENU
   (ID, MENU_NAME, PARENT_MENU_ID, SERIAL_NUM, ISSHOW, 
    DESCRIPTION, CREATE_USER, CREATE_TIME)
 Values
   (5, '消费分析', 1, 3, 1, 
    '消费分析', 1, TO_DATE('09/01/2012 17:36:25', 'MM/DD/YYYY HH24:MI:SS'));
Insert into T_SYS_MENU
   (ID, MENU_NAME, PARENT_MENU_ID, SERIAL_NUM, ISSHOW, 
    DESCRIPTION, CREATE_USER, CREATE_TIME)
 Values
   (6, '消费类别', 3, 1, 1, 
    '消费类别', 1, TO_DATE('09/01/2012 17:36:25', 'MM/DD/YYYY HH24:MI:SS'));
Insert into T_SYS_MENU
   (ID, MENU_NAME, PARENT_MENU_ID, SERIAL_NUM, ISSHOW, 
    DESCRIPTION, CREATE_USER, CREATE_TIME)
 Values
   (7, '消费内容', 3, 2, 1, 
    '消费内容', 1, TO_DATE('09/01/2012 17:36:25', 'MM/DD/YYYY HH24:MI:SS'));
Insert into T_SYS_MENU
   (ID, MENU_NAME, PARENT_MENU_ID, SERIAL_NUM, ISSHOW, 
    DESCRIPTION, CREATE_USER, CREATE_TIME)
 Values
   (8, '工资情况', 3, 3, 1, 
    '工资情况', 1, TO_DATE('09/01/2012 17:36:25', 'MM/DD/YYYY HH24:MI:SS'));
Insert into T_SYS_MENU
   (ID, MENU_NAME, PARENT_MENU_ID, SERIAL_NUM, ISSHOW, 
    DESCRIPTION, CREATE_USER, CREATE_TIME)
 Values
   (9, '日消费统计', 4, 1, 1, 
    '日消费统计', 1, TO_DATE('09/01/2012 17:38:44', 'MM/DD/YYYY HH24:MI:SS'));
Insert into T_SYS_MENU
   (ID, MENU_NAME, PARENT_MENU_ID, SERIAL_NUM, ISSHOW, 
    DESCRIPTION, CREATE_USER, CREATE_TIME)
 Values
   (10, '月消费统计', 4, 2, 1, 
    '月消费统计', 1, TO_DATE('09/01/2012 17:38:44', 'MM/DD/YYYY HH24:MI:SS'));
Insert into T_SYS_MENU
   (ID, MENU_NAME, PARENT_MENU_ID, SERIAL_NUM, ISSHOW, 
    DESCRIPTION, CREATE_USER, CREATE_TIME)
 Values
   (11, '月消费分析', 5, 1, 1, 
    '月消费分析', 1, TO_DATE('09/01/2012 17:39:20', 'MM/DD/YYYY HH24:MI:SS'));
Insert into T_SYS_MENU
   (ID, MENU_NAME, PARENT_MENU_ID, SERIAL_NUM, ISSHOW, 
    DESCRIPTION, CREATE_USER, CREATE_TIME)
 Values
   (12, '年消费分析', 5, 2, 1, 
    '年消费分析', 1, TO_DATE('09/01/2012 17:39:21', 'MM/DD/YYYY HH24:MI:SS'));
Insert into T_SYS_MENU
   (ID, MENU_NAME, PARENT_MENU_ID, SERIAL_NUM, ISSHOW, 
    DESCRIPTION, CREATE_USER, CREATE_TIME)
 Values
   (13, '基础信息', 2, 1, 1, 
    '基础信息', 1, TO_DATE('09/08/2012 22:33:31', 'MM/DD/YYYY HH24:MI:SS'));
Insert into T_SYS_MENU
   (ID, MENU_NAME, MENU_URL, PARENT_MENU_ID, SERIAL_NUM, 
    ISSHOW, DESCRIPTION, CREATE_USER, CREATE_TIME, UPDATE_USER, 
    UPDATE_TIME, MENU_ALIAS)
 Values
   (14, '部门管理', 'jsp/system/dept.jsp', 13, 1, 
    1, '部门管理', 1, TO_DATE('09/08/2012 22:34:05', 'MM/DD/YYYY HH24:MI:SS'), 1, 
    TO_DATE('09/10/2012 23:45:55', 'MM/DD/YYYY HH24:MI:SS'), 'dept');
Insert into T_SYS_MENU
   (ID, MENU_NAME, PARENT_MENU_ID, SERIAL_NUM, ISSHOW, 
    DESCRIPTION, CREATE_USER, CREATE_TIME)
 Values
   (15, '系统信息', 2, 2, 1, 
    '系统信息', 1, TO_DATE('09/08/2012 22:39:45', 'MM/DD/YYYY HH24:MI:SS'));
Insert into T_SYS_MENU
   (ID, MENU_NAME, MENU_URL, PARENT_MENU_ID, SERIAL_NUM, 
    ISSHOW, DESCRIPTION, CREATE_USER, CREATE_TIME, UPDATE_USER, 
    UPDATE_TIME, MENU_ALIAS)
 Values
   (16, '菜单管理', 'jsp/system/menu.jsp', 15, 1, 
    1, '菜单管理', 1, TO_DATE('09/08/2012 22:40:30', 'MM/DD/YYYY HH24:MI:SS'), 1, 
    TO_DATE('09/10/2012 23:46:41', 'MM/DD/YYYY HH24:MI:SS'), 'menu');
Insert into T_SYS_MENU
   (ID, MENU_NAME, MENU_URL, PARENT_MENU_ID, SERIAL_NUM, 
    ISSHOW, DESCRIPTION, CREATE_USER, CREATE_TIME, UPDATE_USER, 
    UPDATE_TIME, MENU_ALIAS)
 Values
   (17, '人员管理', 'jsp/system/person.jsp', 13, 2, 
    1, '人员管理', 1, TO_DATE('09/11/2012 00:23:47', 'MM/DD/YYYY HH24:MI:SS'), 1, 
    TO_DATE('09/15/2012 22:41:10', 'MM/DD/YYYY HH24:MI:SS'), 'person');
Insert into T_SYS_MENU
   (ID, MENU_NAME, MENU_URL, PARENT_MENU_ID, SERIAL_NUM, 
    ISSHOW, DESCRIPTION, CREATE_USER, CREATE_TIME, MENU_ALIAS)
 Values
   (29, '角色管理', 'jsp/system/role.jsp', 13, 3, 
    1, '角色管理', 1, TO_DATE('09/21/2012 17:05:41', 'MM/DD/YYYY HH24:MI:SS'), 'role');
Insert into T_SYS_MENU
   (ID, MENU_NAME, MENU_URL, PARENT_MENU_ID, SERIAL_NUM, 
    ISSHOW, DESCRIPTION, CREATE_USER, CREATE_TIME, UPDATE_USER, 
    UPDATE_TIME)
 Values
   (21, 'aaa', 'aaa', 13, 8, 
    1, 'aaa', 1, TO_DATE('09/11/2012 23:34:04', 'MM/DD/YYYY HH24:MI:SS'), 1, 
    TO_DATE('09/21/2012 17:05:56', 'MM/DD/YYYY HH24:MI:SS'));
COMMIT;
