SET DEFINE OFF;
Insert into T_BLOG_ATTR
   (ID, ATTR_NAME, ATTR_VALUE, DESCRIPTION)
 Values
   (110, 'nickname', '烤馍', '昵称');
Insert into T_BLOG_ATTR
   (ID, ATTR_NAME, ATTR_VALUE, DESCRIPTION)
 Values
   (134, 'github', 'yangchenjava', 'GitHub');
Insert into T_BLOG_ATTR
   (ID, ATTR_NAME, ATTR_VALUE, DESCRIPTION)
 Values
   (133, 'qq', '511636835', 'QQ');
Insert into T_BLOG_ATTR
   (ID, ATTR_NAME, ATTR_VALUE, DESCRIPTION)
 Values
   (135, 'email', 'yangchen_java@126.com', '邮箱');
COMMIT;
