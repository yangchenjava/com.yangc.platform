ALTER TABLE t_sys_acl
 DROP PRIMARY KEY CASCADE;
DROP TABLE t_sys_acl CASCADE CONSTRAINTS;

CREATE TABLE t_sys_acl
(
  ID              NUMBER,
  role_id         NUMBER,
  menu_id         NUMBER,
  operate_status  NUMBER
)
TABLESPACE yangc
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          64 k
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
LOGGING
NOCOMPRESS
NOCACHE
NOPARALLEL
MONITORING;

COMMENT ON TABLE t_sys_acl IS '角色菜单维系表';

COMMENT ON COLUMN t_sys_acl.ID IS '主键';

COMMENT ON COLUMN t_sys_acl.role_id IS '角色ID';

COMMENT ON COLUMN t_sys_acl.menu_id IS '菜单ID';

COMMENT ON COLUMN t_sys_acl.operate_status IS '操作状态值';


ALTER TABLE t_sys_department
 DROP PRIMARY KEY CASCADE;
DROP TABLE t_sys_department CASCADE CONSTRAINTS;

CREATE TABLE t_sys_department
(
  ID           NUMBER,
  dept_name    VARCHAR2(200 BYTE),
  serial_num   NUMBER,
  create_user  NUMBER,
  create_time  DATE                             DEFAULT SYSDATE,
  update_user  NUMBER,
  update_time  DATE
)
TABLESPACE yangc
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          64 k
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
LOGGING
NOCOMPRESS
NOCACHE
NOPARALLEL
MONITORING;

COMMENT ON TABLE t_sys_department IS '部门表';

COMMENT ON COLUMN t_sys_department.ID IS '主键';

COMMENT ON COLUMN t_sys_department.dept_name IS '部门名称';

COMMENT ON COLUMN t_sys_department.serial_num IS '排序号';

COMMENT ON COLUMN t_sys_department.create_user IS '创建者';

COMMENT ON COLUMN t_sys_department.create_time IS '创建时间';

COMMENT ON COLUMN t_sys_department.update_user IS '修改者';

COMMENT ON COLUMN t_sys_department.update_time IS '修改时间';


ALTER TABLE t_sys_menu
 DROP PRIMARY KEY CASCADE;
DROP TABLE t_sys_menu CASCADE CONSTRAINTS;

CREATE TABLE t_sys_menu
(
  ID              NUMBER,
  menu_name       VARCHAR2(200 BYTE),
  menu_url        VARCHAR2(200 BYTE),
  parent_menu_id  NUMBER,
  serial_num      NUMBER,
  isshow          NUMBER(1),
  description     VARCHAR2(200 BYTE),
  create_user     NUMBER,
  create_time     DATE                          DEFAULT SYSDATE,
  update_user     NUMBER,
  update_time     DATE,
  menu_alias      VARCHAR2(200 BYTE)
)
TABLESPACE yangc
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          64 k
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
LOGGING
NOCOMPRESS
NOCACHE
NOPARALLEL
MONITORING;

COMMENT ON TABLE t_sys_menu IS '菜单表';

COMMENT ON COLUMN t_sys_menu.ID IS '主键';

COMMENT ON COLUMN t_sys_menu.menu_name IS '菜单名称';

COMMENT ON COLUMN t_sys_menu.menu_url IS '菜单地址';

COMMENT ON COLUMN t_sys_menu.parent_menu_id IS '父菜单ID';

COMMENT ON COLUMN t_sys_menu.serial_num IS '排序号';

COMMENT ON COLUMN t_sys_menu.isshow IS '是否显示:0不显示;1显示';

COMMENT ON COLUMN t_sys_menu.description IS '菜单描述';

COMMENT ON COLUMN t_sys_menu.create_user IS '创建者';

COMMENT ON COLUMN t_sys_menu.create_time IS '创建时间';

COMMENT ON COLUMN t_sys_menu.update_user IS '修改者';

COMMENT ON COLUMN t_sys_menu.update_time IS '修改时间';

COMMENT ON COLUMN t_sys_menu.menu_alias IS '菜单别名';


ALTER TABLE t_sys_person
 DROP PRIMARY KEY CASCADE;
DROP TABLE t_sys_person CASCADE CONSTRAINTS;

CREATE TABLE t_sys_person
(
  ID           NUMBER,
  NAME         VARCHAR2(50 BYTE),
  sex          NUMBER(1),
  phone        VARCHAR2(50 BYTE),
  dept_id      NUMBER,
  create_user  NUMBER,
  create_time  DATE                             DEFAULT SYSDATE,
  update_user  NUMBER,
  update_time  DATE,
  spell        VARCHAR2(100 BYTE)
)
TABLESPACE yangc
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          64 k
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
LOGGING
NOCOMPRESS
NOCACHE
NOPARALLEL
MONITORING;

COMMENT ON TABLE t_sys_person IS '用户信息表';

COMMENT ON COLUMN t_sys_person.ID IS '主键';

COMMENT ON COLUMN t_sys_person.NAME IS '姓名';

COMMENT ON COLUMN t_sys_person.sex IS '性别,0女,1男';

COMMENT ON COLUMN t_sys_person.phone IS '电话';

COMMENT ON COLUMN t_sys_person.dept_id IS '部门ID';

COMMENT ON COLUMN t_sys_person.create_user IS '创建者';

COMMENT ON COLUMN t_sys_person.create_time IS '创建时间';

COMMENT ON COLUMN t_sys_person.update_user IS '修改者';

COMMENT ON COLUMN t_sys_person.update_time IS '修改时间';

COMMENT ON COLUMN t_sys_person.spell IS '拼写';


ALTER TABLE t_sys_role
 DROP PRIMARY KEY CASCADE;
DROP TABLE t_sys_role CASCADE CONSTRAINTS;

CREATE TABLE t_sys_role
(
  ID           NUMBER,
  role_name    VARCHAR2(200 BYTE),
  create_user  NUMBER,
  create_time  DATE                             DEFAULT SYSDATE,
  update_user  NUMBER,
  update_time  DATE
)
TABLESPACE yangc
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          64 k
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
LOGGING
NOCOMPRESS
NOCACHE
NOPARALLEL
MONITORING;

COMMENT ON TABLE t_sys_role IS '角色表';

COMMENT ON COLUMN t_sys_role.ID IS '主键';

COMMENT ON COLUMN t_sys_role.role_name IS '角色名称';

COMMENT ON COLUMN t_sys_role.create_user IS '创建者';

COMMENT ON COLUMN t_sys_role.create_time IS '创建时间';

COMMENT ON COLUMN t_sys_role.update_user IS '修改者';

COMMENT ON COLUMN t_sys_role.update_time IS '修改时间';


ALTER TABLE t_sys_user
 DROP PRIMARY KEY CASCADE;
DROP TABLE t_sys_user CASCADE CONSTRAINTS;

CREATE TABLE t_sys_user
(
  ID           NUMBER,
  username     VARCHAR2(200 BYTE),
  PASSWORD     VARCHAR2(200 BYTE),
  person_id    NUMBER,
  create_user  NUMBER,
  create_time  DATE                             DEFAULT SYSDATE,
  update_user  NUMBER,
  update_time  DATE
)
TABLESPACE yangc
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          64 k
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
LOGGING
NOCOMPRESS
NOCACHE
NOPARALLEL
MONITORING;

COMMENT ON TABLE t_sys_user IS '用户登录表';

COMMENT ON COLUMN t_sys_user.ID IS '主键';

COMMENT ON COLUMN t_sys_user.username IS '用户名';

COMMENT ON COLUMN t_sys_user.PASSWORD IS '密码';

COMMENT ON COLUMN t_sys_user.person_id IS '用户信息ID';

COMMENT ON COLUMN t_sys_user.create_user IS '创建者';

COMMENT ON COLUMN t_sys_user.create_time IS '创建时间';

COMMENT ON COLUMN t_sys_user.update_user IS '修改者';

COMMENT ON COLUMN t_sys_user.update_time IS '修改时间';


ALTER TABLE t_sys_usersroles
 DROP PRIMARY KEY CASCADE;
DROP TABLE t_sys_usersroles CASCADE CONSTRAINTS;

CREATE TABLE t_sys_usersroles
(
  ID       NUMBER,
  user_id  NUMBER,
  role_id  NUMBER
)
TABLESPACE yangc
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          64 k
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
LOGGING
NOCOMPRESS
NOCACHE
NOPARALLEL
MONITORING;

COMMENT ON TABLE t_sys_usersroles IS '用户角色维系表';

COMMENT ON COLUMN t_sys_usersroles.ID IS '主键';

COMMENT ON COLUMN t_sys_usersroles.user_id IS '用户ID';

COMMENT ON COLUMN t_sys_usersroles.role_id IS '角色ID';


ALTER TABLE t_blog_category
 DROP PRIMARY KEY CASCADE;
DROP TABLE t_blog_category CASCADE CONSTRAINTS;

CREATE TABLE t_blog_category
(
  ID                  NUMBER,
  category_name       VARCHAR2(200 BYTE),
  parent_category_id  NUMBER,
  serial_num          NUMBER,
  create_user         NUMBER,
  create_time         DATE,
  update_user         NUMBER,
  update_time         DATE
)
TABLESPACE yangc
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          64 k
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
LOGGING
NOCOMPRESS
NOCACHE
NOPARALLEL
MONITORING;

COMMENT ON TABLE t_blog_category IS '博文类别表';

COMMENT ON COLUMN t_blog_category.ID IS '主键';

COMMENT ON COLUMN t_blog_category.category_name IS '类别名称';

COMMENT ON COLUMN t_blog_category.parent_category_id IS '父类别ID';

COMMENT ON COLUMN t_blog_category.serial_num IS '排序号';

COMMENT ON COLUMN t_blog_category.create_user IS '创建者';

COMMENT ON COLUMN t_blog_category.create_time IS '创建时间';

COMMENT ON COLUMN t_blog_category.update_user IS '修改者';

COMMENT ON COLUMN t_blog_category.update_time IS '修改时间';


ALTER TABLE t_blog_article
 DROP PRIMARY KEY CASCADE;
DROP TABLE t_blog_article CASCADE CONSTRAINTS;

CREATE TABLE t_blog_article
(
  ID           NUMBER,
  title        VARCHAR2(200 BYTE),
  content      CLOB,
  category_id  NUMBER,
  create_user  NUMBER,
  create_time  DATE,
  update_user  NUMBER,
  update_time  DATE,
  read_count   NUMBER                           DEFAULT 0
)
TABLESPACE yangc
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          64 k
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
LOGGING
NOCOMPRESS
LOB (content) STORE AS
      ( TABLESPACE  yangc
        ENABLE      STORAGE IN ROW
        CHUNK       8192
        RETENTION
        NOCACHE
        INDEX       (
          TABLESPACE yangc
          STORAGE    (
                      INITIAL          64 k
                      NEXT             1
                      MINEXTENTS       1
                      MAXEXTENTS       UNLIMITED
                      PCTINCREASE      0
                      BUFFER_POOL      DEFAULT
                     ))
        STORAGE    (
                    INITIAL          64 k
                    MINEXTENTS       1
                    MAXEXTENTS       UNLIMITED
                    PCTINCREASE      0
                    BUFFER_POOL      DEFAULT
                   )
      )
NOCACHE
NOPARALLEL
MONITORING;

COMMENT ON TABLE t_blog_article IS '博文表';

COMMENT ON COLUMN t_blog_article.ID IS '主键';

COMMENT ON COLUMN t_blog_article.title IS '标题';

COMMENT ON COLUMN t_blog_article.content IS '内容';

COMMENT ON COLUMN t_blog_article.category_id IS '类别ID';

COMMENT ON COLUMN t_blog_article.create_user IS '创建者';

COMMENT ON COLUMN t_blog_article.create_time IS '创建时间';

COMMENT ON COLUMN t_blog_article.update_user IS '修改者';

COMMENT ON COLUMN t_blog_article.update_time IS '修改时间';

COMMENT ON COLUMN t_blog_article.read_count IS '阅读次数';


ALTER TABLE t_blog_comment
 DROP PRIMARY KEY CASCADE;
DROP TABLE t_blog_comment CASCADE CONSTRAINTS;

CREATE TABLE t_blog_comment
(
  ID           NUMBER,
  NAME         VARCHAR2(200 BYTE),
  content      VARCHAR2(1000 BYTE),
  article_id   NUMBER,
  ip_address   VARCHAR2(50 BYTE),
  create_time  DATE
)
TABLESPACE yangc
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          64 k
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
LOGGING
NOCOMPRESS
NOCACHE
NOPARALLEL
MONITORING;

COMMENT ON TABLE t_blog_comment IS '博文评论表';

COMMENT ON COLUMN t_blog_comment.ID IS '主键';

COMMENT ON COLUMN t_blog_comment.NAME IS '评论人';

COMMENT ON COLUMN t_blog_comment.content IS '评论内容';

COMMENT ON COLUMN t_blog_comment.article_id IS '博文ID';

COMMENT ON COLUMN t_blog_comment.ip_address IS 'IP地址';

COMMENT ON COLUMN t_blog_comment.create_time IS '创建时间';


ALTER TABLE t_blog_tag
 DROP PRIMARY KEY CASCADE;
DROP TABLE t_blog_tag CASCADE CONSTRAINTS;

CREATE TABLE t_blog_tag
(
  ID          NUMBER,
  tag_name    VARCHAR2(200 BYTE),
  article_id  NUMBER
)
TABLESPACE yangc
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          64 k
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
LOGGING
NOCOMPRESS
NOCACHE
NOPARALLEL
MONITORING;

COMMENT ON TABLE t_blog_tag IS '博文标签表';

COMMENT ON COLUMN t_blog_tag.ID IS '主键';

COMMENT ON COLUMN t_blog_tag.tag_name IS '标签名称';

COMMENT ON COLUMN t_blog_tag.article_id IS '博文ID';


ALTER TABLE t_blog_attr
 DROP PRIMARY KEY CASCADE;
DROP TABLE t_blog_attr CASCADE CONSTRAINTS;

CREATE TABLE t_blog_attr
(
  ID           NUMBER,
  attr_name    VARCHAR2(200 BYTE),
  attr_value   VARCHAR2(200 BYTE),
  description  VARCHAR2(500 BYTE)
)
TABLESPACE yangc
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          64 k
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
LOGGING
NOCOMPRESS
NOCACHE
NOPARALLEL
MONITORING;

COMMENT ON TABLE t_blog_attr IS '博文属性信息表';

COMMENT ON COLUMN t_blog_attr.ID IS '主键';

COMMENT ON COLUMN t_blog_attr.attr_name IS '属性名';

COMMENT ON COLUMN t_blog_attr.attr_value IS '属性值';

COMMENT ON COLUMN t_blog_attr.description IS '描述';


CREATE UNIQUE INDEX t_blog_article_pk ON t_blog_article
(ID)
LOGGING
TABLESPACE yangc
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64 k
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


CREATE UNIQUE INDEX t_blog_attr_pk ON t_blog_attr
(ID)
LOGGING
TABLESPACE yangc
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64 k
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


CREATE UNIQUE INDEX t_blog_category_pk ON t_blog_category
(ID)
LOGGING
TABLESPACE yangc
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64 k
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


CREATE UNIQUE INDEX t_blog_comment_pk ON t_blog_comment
(ID)
LOGGING
TABLESPACE yangc
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64 k
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


CREATE UNIQUE INDEX t_blog_tag_pk ON t_blog_tag
(ID)
LOGGING
TABLESPACE yangc
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64 k
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


CREATE UNIQUE INDEX t_sys_acl_pk ON t_sys_acl
(ID)
LOGGING
TABLESPACE yangc
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64 k
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


CREATE UNIQUE INDEX t_sys_department_pk ON t_sys_department
(ID)
LOGGING
TABLESPACE yangc
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64 k
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


CREATE UNIQUE INDEX t_sys_menu_pk ON t_sys_menu
(ID)
LOGGING
TABLESPACE yangc
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64 k
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


CREATE UNIQUE INDEX t_sys_person_pk ON t_sys_person
(ID)
LOGGING
TABLESPACE yangc
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64 k
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


CREATE UNIQUE INDEX t_sys_role_pk ON t_sys_role
(ID)
LOGGING
TABLESPACE yangc
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64 k
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


CREATE UNIQUE INDEX t_sys_usersroles_pk ON t_sys_usersroles
(ID)
LOGGING
TABLESPACE yangc
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64 k
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


CREATE UNIQUE INDEX t_sys_user_pk ON t_sys_user
(ID)
LOGGING
TABLESPACE yangc
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64 k
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


ALTER TABLE t_sys_acl ADD (
  CONSTRAINT t_sys_acl_pk
 PRIMARY KEY
 (ID)
    USING INDEX
    TABLESPACE yangc
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          64 k
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
               ));

ALTER TABLE t_sys_department ADD (
  CONSTRAINT t_sys_department_pk
 PRIMARY KEY
 (ID)
    USING INDEX
    TABLESPACE yangc
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          64 k
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
               ));

ALTER TABLE t_sys_menu ADD (
  CONSTRAINT t_sys_menu_pk
 PRIMARY KEY
 (ID)
    USING INDEX
    TABLESPACE yangc
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          64 k
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
               ));

ALTER TABLE t_sys_person ADD (
  CONSTRAINT t_sys_person_pk
 PRIMARY KEY
 (ID)
    USING INDEX
    TABLESPACE yangc
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          64 k
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
               ));

ALTER TABLE t_sys_role ADD (
  CONSTRAINT t_sys_role_pk
 PRIMARY KEY
 (ID)
    USING INDEX
    TABLESPACE yangc
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          64 k
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
               ));

ALTER TABLE t_sys_user ADD (
  CONSTRAINT t_sys_user_pk
 PRIMARY KEY
 (ID)
    USING INDEX
    TABLESPACE yangc
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          64 k
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
               ));

ALTER TABLE t_sys_usersroles ADD (
  CONSTRAINT t_sys_usersroles_pk
 PRIMARY KEY
 (ID)
    USING INDEX
    TABLESPACE yangc
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          64 k
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
               ));

ALTER TABLE t_blog_category ADD (
  CONSTRAINT t_blog_category_pk
 PRIMARY KEY
 (ID)
    USING INDEX
    TABLESPACE yangc
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          64 k
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
               ));

ALTER TABLE t_blog_article ADD (
  CONSTRAINT t_blog_article_pk
 PRIMARY KEY
 (ID)
    USING INDEX
    TABLESPACE yangc
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          64 k
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
               ));

ALTER TABLE t_blog_comment ADD (
  CONSTRAINT t_blog_comment_pk
 PRIMARY KEY
 (ID)
    USING INDEX
    TABLESPACE yangc
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          64 k
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
               ));

ALTER TABLE t_blog_tag ADD (
  CONSTRAINT t_blog_tag_pk
 PRIMARY KEY
 (ID)
    USING INDEX
    TABLESPACE yangc
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          64 k
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
               ));

ALTER TABLE t_blog_attr ADD (
  CONSTRAINT t_blog_attr_pk
 PRIMARY KEY
 (ID)
    USING INDEX
    TABLESPACE yangc
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          64 k
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
               ));


DROP SEQUENCE hibernate_seq;

CREATE SEQUENCE hibernate_seq
  START WITH 148
  MAXVALUE 99999999999999
  MINVALUE 1
  NOCYCLE
  NOCACHE
  NOORDER;



DROP PROCEDURE my_procedure;

CREATE OR REPLACE PROCEDURE my_procedure (v_sex IN NUMBER, v_result OUT my_package.v_result)
IS
BEGIN
   OPEN v_result FOR
      SELECT NAME, phone
        FROM t_sys_person
       WHERE sex = v_sex;
END my_procedure;
/

DROP PROCEDURE my_procedure_2;

CREATE OR REPLACE PROCEDURE my_procedure_2 (v_id IN t_sys_test.ID%TYPE, v_name IN t_sys_test.NAME%TYPE)
IS
BEGIN
   INSERT INTO t_sys_test
               (ID, NAME
               )
        VALUES (v_id, v_name
               );

   COMMIT;
END my_procedure_2;
/

DROP PROCEDURE my_procedure_3;

CREATE OR REPLACE PROCEDURE my_procedure_3 (v_tablename IN VARCHAR2, v_firstresult IN NUMBER, v_maxresults IN NUMBER, v_totalcount OUT NUMBER, v_totalpage OUT NUMBER, v_result OUT my_package.v_result)
IS
   v_sql   VARCHAR2 (500);
BEGIN
   v_sql := 'SELECT * FROM (SELECT temp.*, ROWNUM r FROM (SELECT * FROM ' || v_tablename || ' ORDER BY ID) temp WHERE ROWNUM <= ' || (v_firstresult + v_maxresults) || ') WHERE r > ' || v_firstresult;

   OPEN v_result FOR v_sql;

   v_sql := 'SELECT COUNT (1) FROM ' || v_tablename;

   EXECUTE IMMEDIATE v_sql
                INTO v_totalcount;

   v_totalpage := CEIL (v_totalcount / v_maxresults);
END my_procedure_3;
/


DROP PACKAGE my_package;

CREATE OR REPLACE PACKAGE my_package
IS
   TYPE v_result IS REF CURSOR;
END my_package;
/
