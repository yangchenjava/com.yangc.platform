SET DEFINE OFF;
Insert into T_BLOG_TAG
   (ID, TAG_NAME, ARTICLE_ID)
 Values
   (1, 'ddd', 136);
COMMIT;
