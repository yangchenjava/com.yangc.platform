SET DEFINE OFF;
Insert into T_BLOG_COMMENT
   (ID, NAME, CONTENT, ARTICLE_ID, IP_ADDRESS, 
    CREATE_TIME)
 Values
   (146, 'yangc', '还不错，可以理解，评论文字的颜色清晰些就更好了。。。', 136, '127.0.0.1', 
    TO_DATE('08/04/2014 19:12:50', 'MM/DD/YYYY HH24:MI:SS'));
Insert into T_BLOG_COMMENT
   (ID, NAME, CONTENT, ARTICLE_ID, IP_ADDRESS, 
    CREATE_TIME)
 Values
   (147, 'jeckson', '@yangc 我也是这么认为', 136, '127.0.0.1', 
    TO_DATE('08/04/2014 19:15:38', 'MM/DD/YYYY HH24:MI:SS'));
COMMIT;
