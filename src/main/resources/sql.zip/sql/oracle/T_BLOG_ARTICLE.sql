SET DEFINE OFF;
Insert into T_BLOG_ARTICLE
   (ID, TITLE, CONTENT, CATEGORY_ID, CREATE_USER, 
    CREATE_TIME, UPDATE_USER, UPDATE_TIME, READ_COUNT)
 Values
   (136, 'JVM_体系结构', '<p style="text-align:center"><img src="/../upload/image/20140731/1406803467993030229.jpeg" title="1406803467993030229.jpeg" alt="2012050808411063.jpeg"/></p><p style="font-family: 微软雅黑; font-size: 14px; white-space: normal;">下面先对图中各部分做个简单的说明：</p><p style="font-family: 微软雅黑; font-size: 14px; white-space: normal;">1.class文件：虚拟机并不关心Class的来源是什么语言，只要它符合Java class文件格式就可以在Java虚拟机中运行。使用Java编译器可以把Java代码编译为存储字节码的Class文件，使用JRuby等其他语言的编译器一样可以把程序代码编译成Class文件。</p><p style="font-family: 微软雅黑; font-size: 14px; white-space: normal;">2.类装载器子系统：负责查找并装载Class 文件到内存，最终形成可以被虚拟机直接使用的Java类型。</p><p style="font-family: 微软雅黑; font-size: 14px; white-space: normal;">3.方法区：在类装载器加载class文件到内存的过程中，虚拟机会提取其中的类型信息，并将这些信息存储到方法区。方法区用于存储已被虚拟机加载的类信息、常量、静态变量、即时编译器编译后的代码等数据。由于所有线程都共享方法区，因此它们对方法区数据的访问必须被设计为是线程安全的。</p><p style="font-family: 微软雅黑; font-size: 14px; white-space: normal;">4.堆：存储Java程序创建的类实例。所有线程共享，因此设计程序时也要考虑到多线程访问对象(堆数据)的同步问题。</p><p style="font-family: 微软雅黑; font-size: 14px; white-space: normal;">5.Java栈：Java栈是线程私有的。每当启动一个新线程时，Java虚拟机都会为它分配一个Java栈。Java栈以帧为单位保存线程的运行状态。虚拟机只会直接对Java栈执行两种操作：以帧为单位的压栈或出栈。当线程调用java方法时，虚拟机压入一个新的栈帧到该线程的java栈中。当方法返回时，这个栈帧被从java栈中弹出并抛弃。一个栈帧包含一个java方法的调用状态，它存储有局部变量表、操作栈、动态链接、方法出口等信息。</p><p style="font-family: 微软雅黑; font-size: 14px; white-space: normal;">&nbsp;6.程序计数器：一个运行中的Java程序，每当启动一个新线程时，都会为这个新线程创建一个自己的PC(程序计数器)寄存器。程序计数器的作用可以看做是当前线程所执行的字节码的行号指示器。字节码解释器工作时就是通过改变这个计数器的值来选取下一条需要执行的字节码指令，分支、循环、跳转、异常处理、线程恢复等基础功能都需要依赖这个计数器来完成。如果线程正在执行的是一个Java方法，这个计数器记录的是正在执行的虚拟机字节码指令的地址；如果正在执行的是Natvie方法，这个计数器值则为空(Undefined)。</p><p style="font-family: 微软雅黑; font-size: 14px; white-space: normal;">7.本地方法栈：本地方法栈与虚拟机栈所发挥的作用是非常相似的，其区别不过是虚拟机栈为虚拟机执行Java方法（也就是字节码）服务，而本地方法栈则是为虚拟机使用到的Native方法服务。任何本地方法接口都会使用某种本地方法栈。当线程调用Java方法时，虚拟机会创建一个新的栈帧并压入Java栈。然而当它调用的是本地方法时，虚拟机会保持Java栈不变，不再在线程的Java栈中压入新的帧，虚拟机只是简单地动态链接并直接调用指定的本地方法。如果某个虚拟机实现的本地方法接口是使用C连接模型的话，那么它的本地方法栈就是C栈。</p><p style="font-family: 微软雅黑; font-size: 14px; white-space: normal;">8.执行引擎：负责执行字节码。方法的字节码是由Java虚拟机的指令序列构成的。每一条指令包含一个单字节的操作码，后面跟随0个或多个操作数。执行引擎执行字节码时，首先取得一个操作码，如果操作码有操作数，取得它的操作数。它执行操作码和跟随的操作数规定的动作，然后再取得下一个操作码。这个执行字节码的过程在线程完成前将一直持续。</p><p><br/></p>', 112, 1, 
    TO_DATE('07/31/2014 18:50:19', 'MM/DD/YYYY HH24:MI:SS'), NULL, NULL, 114);
Insert into T_BLOG_ARTICLE
   (ID, TITLE, CONTENT, CATEGORY_ID, CREATE_USER, 
    CREATE_TIME, UPDATE_USER, UPDATE_TIME, READ_COUNT)
 Values
   (145, 'test', '<p>test</p><p>df</p><p>sdfs</p><p>sdfsf</p>', 116, 1, 
    TO_DATE('08/01/2014 13:52:52', 'MM/DD/YYYY HH24:MI:SS'), NULL, NULL, 0);
COMMIT;
