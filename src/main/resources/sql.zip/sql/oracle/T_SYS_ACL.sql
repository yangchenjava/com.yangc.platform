﻿SET DEFINE OFF;
Insert into T_SYS_ACL
   (ID, ROLE_ID, MENU_ID, OPERATE_STATUS)
 Values
   (37, 30, 13, 15);
Insert into T_SYS_ACL
   (ID, ROLE_ID, MENU_ID, OPERATE_STATUS)
 Values
   (38, 30, 15, 15);
Insert into T_SYS_ACL
   (ID, ROLE_ID, MENU_ID, OPERATE_STATUS)
 Values
   (39, 30, 16, 15);
Insert into T_SYS_ACL
   (ID, ROLE_ID, MENU_ID, OPERATE_STATUS)
 Values
   (40, 30, 14, 11);
Insert into T_SYS_ACL
   (ID, ROLE_ID, MENU_ID, OPERATE_STATUS)
 Values
   (41, 30, 2, 15);
Insert into T_SYS_ACL
   (ID, ROLE_ID, MENU_ID, OPERATE_STATUS)
 Values
   (43, 42, 2, 0);
Insert into T_SYS_ACL
   (ID, ROLE_ID, MENU_ID, OPERATE_STATUS)
 Values
   (44, 42, 13, 0);
Insert into T_SYS_ACL
   (ID, ROLE_ID, MENU_ID, OPERATE_STATUS)
 Values
   (45, 42, 14, 0);
Insert into T_SYS_ACL
   (ID, ROLE_ID, MENU_ID, OPERATE_STATUS)
 Values
   (46, 42, 17, 0);
Insert into T_SYS_ACL
   (ID, ROLE_ID, MENU_ID, OPERATE_STATUS)
 Values
   (53, 30, 1, 15);
Insert into T_SYS_ACL
   (ID, ROLE_ID, MENU_ID, OPERATE_STATUS)
 Values
   (54, 30, 3, 15);
Insert into T_SYS_ACL
   (ID, ROLE_ID, MENU_ID, OPERATE_STATUS)
 Values
   (55, 30, 6, 15);
Insert into T_SYS_ACL
   (ID, ROLE_ID, MENU_ID, OPERATE_STATUS)
 Values
   (56, 30, 7, 15);
Insert into T_SYS_ACL
   (ID, ROLE_ID, MENU_ID, OPERATE_STATUS)
 Values
   (57, 30, 8, 15);
Insert into T_SYS_ACL
   (ID, ROLE_ID, MENU_ID, OPERATE_STATUS)
 Values
   (58, 30, 4, 15);
Insert into T_SYS_ACL
   (ID, ROLE_ID, MENU_ID, OPERATE_STATUS)
 Values
   (59, 30, 9, 15);
Insert into T_SYS_ACL
   (ID, ROLE_ID, MENU_ID, OPERATE_STATUS)
 Values
   (60, 30, 10, 15);
Insert into T_SYS_ACL
   (ID, ROLE_ID, MENU_ID, OPERATE_STATUS)
 Values
   (61, 30, 5, 15);
Insert into T_SYS_ACL
   (ID, ROLE_ID, MENU_ID, OPERATE_STATUS)
 Values
   (62, 30, 11, 15);
Insert into T_SYS_ACL
   (ID, ROLE_ID, MENU_ID, OPERATE_STATUS)
 Values
   (63, 30, 12, 15);
Insert into T_SYS_ACL
   (ID, ROLE_ID, MENU_ID, OPERATE_STATUS)
 Values
   (64, 30, 17, 15);
Insert into T_SYS_ACL
   (ID, ROLE_ID, MENU_ID, OPERATE_STATUS)
 Values
   (65, 30, 29, 15);
Insert into T_SYS_ACL
   (ID, ROLE_ID, MENU_ID, OPERATE_STATUS)
 Values
   (66, 30, 21, 15);
Insert into T_SYS_ACL
   (ID, ROLE_ID, MENU_ID, OPERATE_STATUS)
 Values
   (67, 42, 1, 15);
Insert into T_SYS_ACL
   (ID, ROLE_ID, MENU_ID, OPERATE_STATUS)
 Values
   (68, 42, 3, 15);
Insert into T_SYS_ACL
   (ID, ROLE_ID, MENU_ID, OPERATE_STATUS)
 Values
   (69, 42, 4, 15);
Insert into T_SYS_ACL
   (ID, ROLE_ID, MENU_ID, OPERATE_STATUS)
 Values
   (70, 42, 5, 15);
Insert into T_SYS_ACL
   (ID, ROLE_ID, MENU_ID, OPERATE_STATUS)
 Values
   (71, 42, 6, 15);
Insert into T_SYS_ACL
   (ID, ROLE_ID, MENU_ID, OPERATE_STATUS)
 Values
   (72, 42, 7, 15);
Insert into T_SYS_ACL
   (ID, ROLE_ID, MENU_ID, OPERATE_STATUS)
 Values
   (73, 42, 8, 15);
Insert into T_SYS_ACL
   (ID, ROLE_ID, MENU_ID, OPERATE_STATUS)
 Values
   (74, 42, 9, 15);
Insert into T_SYS_ACL
   (ID, ROLE_ID, MENU_ID, OPERATE_STATUS)
 Values
   (75, 42, 10, 15);
Insert into T_SYS_ACL
   (ID, ROLE_ID, MENU_ID, OPERATE_STATUS)
 Values
   (76, 42, 11, 15);
Insert into T_SYS_ACL
   (ID, ROLE_ID, MENU_ID, OPERATE_STATUS)
 Values
   (77, 42, 12, 15);
COMMIT;
