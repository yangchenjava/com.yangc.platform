SET DEFINE OFF;
Insert into T_SYS_USERSROLES
   (ID, USER_ID, ROLE_ID)
 Values
   (47, 1, 30);
Insert into T_SYS_USERSROLES
   (ID, USER_ID, ROLE_ID)
 Values
   (48, 1, 42);
Insert into T_SYS_USERSROLES
   (ID, USER_ID, ROLE_ID)
 Values
   (51, 23, 42);
Insert into T_SYS_USERSROLES
   (ID, USER_ID, ROLE_ID)
 Values
   (52, 28, 42);
Insert into T_SYS_USERSROLES
   (ID, USER_ID, ROLE_ID)
 Values
   (109, 106, 42);
COMMIT;
