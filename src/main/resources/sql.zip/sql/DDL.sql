﻿--
-- Create Schema Script 
--   Database Version          : 10.2.0.1.0 
--   Database Compatible Level : 10.2.0.1.0 
--   Script Compatible Level   : 10.2.0.1.0 
--   Toad Version              : 12.0.0.61 
--   DB Connect String         : 127.0.0.1:1521/MIS 
--   Schema                    : YANGC 
--   Script Created by         : YANGC 
--   Script Created at         : 2014/6/25 20:00:50 
--   Physical Location         :  
--   Notes                     :  
--

-- Object Counts: 
--   Indexes: 8         Columns: 8          
--   Packages: 1        Lines of Code: 4 
--   Procedures: 3      Lines of Code: 53 
--   Sequences: 1 
--   Tables: 8          Columns: 53         Constraints: 8      


-- "Set define off" turns off substitution variables. 
Set define off; 

--
-- T_SYS_ACL  (Table) 
--
CREATE TABLE YANGC.T_SYS_ACL
(
  ID              NUMBER,
  ROLE_ID         NUMBER,
  MENU_ID         NUMBER,
  OPERATE_STATUS  NUMBER
)
TABLESPACE YANGC
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOCOMPRESS ;

COMMENT ON TABLE YANGC.T_SYS_ACL IS '角色菜单维系表';

COMMENT ON COLUMN YANGC.T_SYS_ACL.ID IS '主键';

COMMENT ON COLUMN YANGC.T_SYS_ACL.ROLE_ID IS '角色ID';

COMMENT ON COLUMN YANGC.T_SYS_ACL.MENU_ID IS '菜单ID';

COMMENT ON COLUMN YANGC.T_SYS_ACL.OPERATE_STATUS IS '操作状态值';



--
-- T_SYS_DEPARTMENT  (Table) 
--
CREATE TABLE YANGC.T_SYS_DEPARTMENT
(
  ID           NUMBER,
  DEPT_NAME    VARCHAR2(200 BYTE),
  SERIAL_NUM   NUMBER,
  CREATE_USER  NUMBER,
  CREATE_TIME  DATE                             DEFAULT SYSDATE,
  UPDATE_USER  NUMBER,
  UPDATE_TIME  DATE
)
TABLESPACE YANGC
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOCOMPRESS ;

COMMENT ON TABLE YANGC.T_SYS_DEPARTMENT IS '部门表';

COMMENT ON COLUMN YANGC.T_SYS_DEPARTMENT.ID IS '主键';

COMMENT ON COLUMN YANGC.T_SYS_DEPARTMENT.DEPT_NAME IS '部门名称';

COMMENT ON COLUMN YANGC.T_SYS_DEPARTMENT.SERIAL_NUM IS '排序号';

COMMENT ON COLUMN YANGC.T_SYS_DEPARTMENT.CREATE_USER IS '创建者';

COMMENT ON COLUMN YANGC.T_SYS_DEPARTMENT.CREATE_TIME IS '创建时间';

COMMENT ON COLUMN YANGC.T_SYS_DEPARTMENT.UPDATE_USER IS '修改者';

COMMENT ON COLUMN YANGC.T_SYS_DEPARTMENT.UPDATE_TIME IS '修改时间';



--
-- T_SYS_MENU  (Table) 
--
CREATE TABLE YANGC.T_SYS_MENU
(
  ID              NUMBER,
  MENU_NAME       VARCHAR2(200 BYTE),
  MENU_URL        VARCHAR2(200 BYTE),
  PARENT_MENU_ID  NUMBER,
  SERIAL_NUM      NUMBER,
  ISSHOW          NUMBER(1),
  DESCRIPTION     VARCHAR2(200 BYTE),
  CREATE_USER     NUMBER,
  CREATE_TIME     DATE                          DEFAULT SYSDATE,
  UPDATE_USER     NUMBER,
  UPDATE_TIME     DATE,
  MENU_ALIAS      VARCHAR2(200 BYTE)
)
TABLESPACE YANGC
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOCOMPRESS ;

COMMENT ON TABLE YANGC.T_SYS_MENU IS '菜单表';

COMMENT ON COLUMN YANGC.T_SYS_MENU.ID IS '主键';

COMMENT ON COLUMN YANGC.T_SYS_MENU.MENU_NAME IS '菜单名称';

COMMENT ON COLUMN YANGC.T_SYS_MENU.MENU_URL IS '菜单地址';

COMMENT ON COLUMN YANGC.T_SYS_MENU.PARENT_MENU_ID IS '父菜单ID';

COMMENT ON COLUMN YANGC.T_SYS_MENU.SERIAL_NUM IS '排序号';

COMMENT ON COLUMN YANGC.T_SYS_MENU.ISSHOW IS '是否显示:0不显示;1显示';

COMMENT ON COLUMN YANGC.T_SYS_MENU.DESCRIPTION IS '菜单描述';

COMMENT ON COLUMN YANGC.T_SYS_MENU.CREATE_USER IS '创建者';

COMMENT ON COLUMN YANGC.T_SYS_MENU.CREATE_TIME IS '创建时间';

COMMENT ON COLUMN YANGC.T_SYS_MENU.UPDATE_USER IS '修改者';

COMMENT ON COLUMN YANGC.T_SYS_MENU.UPDATE_TIME IS '修改时间';

COMMENT ON COLUMN YANGC.T_SYS_MENU.MENU_ALIAS IS '菜单别名';



--
-- T_SYS_PERSON  (Table) 
--
CREATE TABLE YANGC.T_SYS_PERSON
(
  ID           NUMBER,
  NAME         VARCHAR2(50 BYTE),
  SEX          NUMBER(1),
  PHONE        VARCHAR2(50 BYTE),
  DEPT_ID      NUMBER,
  CREATE_USER  NUMBER,
  CREATE_TIME  DATE                             DEFAULT SYSDATE,
  UPDATE_USER  NUMBER,
  UPDATE_TIME  DATE,
  SPELL        VARCHAR2(100 BYTE)
)
TABLESPACE YANGC
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOCOMPRESS ;

COMMENT ON TABLE YANGC.T_SYS_PERSON IS '用户信息表';

COMMENT ON COLUMN YANGC.T_SYS_PERSON.ID IS '主键';

COMMENT ON COLUMN YANGC.T_SYS_PERSON.NAME IS '姓名';

COMMENT ON COLUMN YANGC.T_SYS_PERSON.SEX IS '性别,0女,1男';

COMMENT ON COLUMN YANGC.T_SYS_PERSON.PHONE IS '电话';

COMMENT ON COLUMN YANGC.T_SYS_PERSON.DEPT_ID IS '部门表外键';

COMMENT ON COLUMN YANGC.T_SYS_PERSON.CREATE_USER IS '创建者';

COMMENT ON COLUMN YANGC.T_SYS_PERSON.CREATE_TIME IS '创建时间';

COMMENT ON COLUMN YANGC.T_SYS_PERSON.UPDATE_USER IS '修改者';

COMMENT ON COLUMN YANGC.T_SYS_PERSON.UPDATE_TIME IS '修改时间';

COMMENT ON COLUMN YANGC.T_SYS_PERSON.SPELL IS '拼写';



--
-- T_SYS_ROLE  (Table) 
--
CREATE TABLE YANGC.T_SYS_ROLE
(
  ID           NUMBER,
  ROLE_NAME    VARCHAR2(200 BYTE),
  CREATE_USER  NUMBER,
  CREATE_TIME  DATE                             DEFAULT SYSDATE,
  UPDATE_USER  NUMBER,
  UPDATE_TIME  DATE
)
TABLESPACE YANGC
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOCOMPRESS ;

COMMENT ON TABLE YANGC.T_SYS_ROLE IS '角色表';

COMMENT ON COLUMN YANGC.T_SYS_ROLE.ID IS '主键';

COMMENT ON COLUMN YANGC.T_SYS_ROLE.ROLE_NAME IS '角色名称';

COMMENT ON COLUMN YANGC.T_SYS_ROLE.CREATE_USER IS '创建者';

COMMENT ON COLUMN YANGC.T_SYS_ROLE.CREATE_TIME IS '创建时间';

COMMENT ON COLUMN YANGC.T_SYS_ROLE.UPDATE_USER IS '修改者';

COMMENT ON COLUMN YANGC.T_SYS_ROLE.UPDATE_TIME IS '修改时间';



--
-- T_SYS_TEST  (Table) 
--
CREATE TABLE YANGC.T_SYS_TEST
(
  ID     NUMBER,
  NAME   VARCHAR2(200 BYTE),
  VALUE  VARCHAR2(200 BYTE)
)
TABLESPACE YANGC
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOCOMPRESS ;


--
-- T_SYS_USER  (Table) 
--
CREATE TABLE YANGC.T_SYS_USER
(
  ID           NUMBER,
  USERNAME     VARCHAR2(200 BYTE),
  PASSWORD     VARCHAR2(200 BYTE),
  PERSON_ID    NUMBER,
  CREATE_USER  NUMBER,
  CREATE_TIME  DATE                             DEFAULT SYSDATE,
  UPDATE_USER  NUMBER,
  UPDATE_TIME  DATE
)
TABLESPACE YANGC
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOCOMPRESS ;

COMMENT ON TABLE YANGC.T_SYS_USER IS '用户登录表';

COMMENT ON COLUMN YANGC.T_SYS_USER.ID IS '主键';

COMMENT ON COLUMN YANGC.T_SYS_USER.USERNAME IS '用户名';

COMMENT ON COLUMN YANGC.T_SYS_USER.PASSWORD IS '密码';

COMMENT ON COLUMN YANGC.T_SYS_USER.PERSON_ID IS '用户信息表外键';

COMMENT ON COLUMN YANGC.T_SYS_USER.CREATE_USER IS '创建者';

COMMENT ON COLUMN YANGC.T_SYS_USER.CREATE_TIME IS '创建时间';

COMMENT ON COLUMN YANGC.T_SYS_USER.UPDATE_USER IS '修改者';

COMMENT ON COLUMN YANGC.T_SYS_USER.UPDATE_TIME IS '修改时间';



--
-- T_SYS_USERSROLES  (Table) 
--
CREATE TABLE YANGC.T_SYS_USERSROLES
(
  ID       NUMBER,
  USER_ID  NUMBER,
  ROLE_ID  NUMBER
)
TABLESPACE YANGC
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOCOMPRESS ;

COMMENT ON TABLE YANGC.T_SYS_USERSROLES IS '用户角色维系表';

COMMENT ON COLUMN YANGC.T_SYS_USERSROLES.ID IS '主键';

COMMENT ON COLUMN YANGC.T_SYS_USERSROLES.USER_ID IS '用户ID';

COMMENT ON COLUMN YANGC.T_SYS_USERSROLES.ROLE_ID IS '角色ID';



--
-- HIBERNATE_SEQ  (Sequence) 
--
CREATE SEQUENCE YANGC.HIBERNATE_SEQ
  START WITH 104
  MAXVALUE 99999999999999
  MINVALUE 1
  NOCYCLE
  NOCACHE
  NOORDER;


--
-- T_SYS_ACL_PK  (Index) 
--
CREATE UNIQUE INDEX YANGC.T_SYS_ACL_PK ON YANGC.T_SYS_ACL
(ID)
TABLESPACE YANGC
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           );


--
-- T_SYS_DEPARTMENT_PK  (Index) 
--
CREATE UNIQUE INDEX YANGC.T_SYS_DEPARTMENT_PK ON YANGC.T_SYS_DEPARTMENT
(ID)
TABLESPACE YANGC
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           );


--
-- T_SYS_MENU_PK  (Index) 
--
CREATE UNIQUE INDEX YANGC.T_SYS_MENU_PK ON YANGC.T_SYS_MENU
(ID)
TABLESPACE YANGC
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           );


--
-- T_SYS_PERSON_PK  (Index) 
--
CREATE UNIQUE INDEX YANGC.T_SYS_PERSON_PK ON YANGC.T_SYS_PERSON
(ID)
TABLESPACE YANGC
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           );


--
-- T_SYS_ROLE_PK  (Index) 
--
CREATE UNIQUE INDEX YANGC.T_SYS_ROLE_PK ON YANGC.T_SYS_ROLE
(ID)
TABLESPACE YANGC
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           );


--
-- T_SYS_USER_PK  (Index) 
--
CREATE UNIQUE INDEX YANGC.T_SYS_USER_PK ON YANGC.T_SYS_USER
(ID)
TABLESPACE YANGC
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           );


--
-- T_SYS_USERSROLES_PK  (Index) 
--
CREATE UNIQUE INDEX YANGC.T_SYS_USERSROLES_PK ON YANGC.T_SYS_USERSROLES
(ID)
TABLESPACE YANGC
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           );


--
-- MY_PACKAGE  (Package) 
--
CREATE OR REPLACE PACKAGE YANGC.my_package
IS
   TYPE v_result IS REF CURSOR;
END my_package; 
/

--
-- MY_PROCEDURE  (Procedure) 
--
CREATE OR REPLACE PROCEDURE YANGC.my_procedure (
   v_sex      IN       NUMBER,
   v_result   OUT      my_package.v_result
)
IS
BEGIN
   OPEN v_result FOR
      SELECT NAME, phone
        FROM t_sys_person
       WHERE sex = v_sex;
END my_procedure; 
/

--
-- MY_PROCEDURE_3  (Procedure) 
--
CREATE OR REPLACE PROCEDURE YANGC.my_procedure_3 (
   v_tablename     IN       VARCHAR2,
   v_firstresult   IN       NUMBER,
   v_maxresults    IN       NUMBER,
   v_totalcount    OUT      NUMBER,
   v_totalpage     OUT      NUMBER,
   v_result        OUT      my_package.v_result
)
IS
   v_sql   VARCHAR2 (500);
BEGIN
   v_sql :=
         'SELECT * FROM (SELECT temp.*, ROWNUM r FROM (SELECT * FROM '
      || v_tablename
      || ' ORDER BY ID) temp WHERE ROWNUM <= '
      || (v_firstresult + v_maxresults)
      || ') WHERE r > '
      || v_firstresult;

   OPEN v_result FOR v_sql;

   v_sql := 'SELECT COUNT (1) FROM ' || v_tablename;

   EXECUTE IMMEDIATE v_sql
                INTO v_totalcount;

   v_totalpage := CEIL (v_totalcount / v_maxresults);
END my_procedure_3; 
/

--
-- MY_PROCEDURE_2  (Procedure) 
--
CREATE OR REPLACE PROCEDURE YANGC.my_procedure_2 (
   v_id     IN   t_sys_test.ID%TYPE,
   v_name   IN   t_sys_test.NAME%TYPE
)
IS
BEGIN
   INSERT INTO t_sys_test
               (ID, NAME
               )
        VALUES (v_id, v_name
               );

   COMMIT;
END my_procedure_2; 
/

-- 
-- Non Foreign Key Constraints for Table T_SYS_ACL 
-- 
ALTER TABLE YANGC.T_SYS_ACL ADD (
  CONSTRAINT T_SYS_ACL_PK
  PRIMARY KEY
  (ID)
  USING INDEX YANGC.T_SYS_ACL_PK
  ENABLE VALIDATE);


-- 
-- Non Foreign Key Constraints for Table T_SYS_DEPARTMENT 
-- 
ALTER TABLE YANGC.T_SYS_DEPARTMENT ADD (
  CONSTRAINT T_SYS_DEPARTMENT_PK
  PRIMARY KEY
  (ID)
  USING INDEX YANGC.T_SYS_DEPARTMENT_PK
  ENABLE VALIDATE);


-- 
-- Non Foreign Key Constraints for Table T_SYS_MENU 
-- 
ALTER TABLE YANGC.T_SYS_MENU ADD (
  CONSTRAINT T_SYS_MENU_PK
  PRIMARY KEY
  (ID)
  USING INDEX YANGC.T_SYS_MENU_PK
  ENABLE VALIDATE);


-- 
-- Non Foreign Key Constraints for Table T_SYS_PERSON 
-- 
ALTER TABLE YANGC.T_SYS_PERSON ADD (
  CONSTRAINT T_SYS_PERSON_PK
  PRIMARY KEY
  (ID)
  USING INDEX YANGC.T_SYS_PERSON_PK
  ENABLE VALIDATE);


-- 
-- Non Foreign Key Constraints for Table T_SYS_ROLE 
-- 
ALTER TABLE YANGC.T_SYS_ROLE ADD (
  CONSTRAINT T_SYS_ROLE_PK
  PRIMARY KEY
  (ID)
  USING INDEX YANGC.T_SYS_ROLE_PK
  ENABLE VALIDATE);


-- 
-- Non Foreign Key Constraints for Table T_SYS_TEST 
-- 
ALTER TABLE YANGC.T_SYS_TEST ADD (
  PRIMARY KEY
  (ID)
  USING INDEX
    TABLESPACE YANGC
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          64K
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                BUFFER_POOL      DEFAULT
               )
  ENABLE VALIDATE);


-- 
-- Non Foreign Key Constraints for Table T_SYS_USER 
-- 
ALTER TABLE YANGC.T_SYS_USER ADD (
  CONSTRAINT T_SYS_USER_PK
  PRIMARY KEY
  (ID)
  USING INDEX YANGC.T_SYS_USER_PK
  ENABLE VALIDATE);


-- 
-- Non Foreign Key Constraints for Table T_SYS_USERSROLES 
-- 
ALTER TABLE YANGC.T_SYS_USERSROLES ADD (
  CONSTRAINT T_SYS_USERSROLES_PK
  PRIMARY KEY
  (ID)
  USING INDEX YANGC.T_SYS_USERSROLES_PK
  ENABLE VALIDATE);