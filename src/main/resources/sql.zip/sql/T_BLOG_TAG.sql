﻿SET DEFINE OFF;
Insert into T_BLOG_TAG
   (ID, TAG_NAME, ARTICLE_ID)
 Values
   (122, '测试', 121);
Insert into T_BLOG_TAG
   (ID, TAG_NAME, ARTICLE_ID)
 Values
   (123, 'demo', 121);
Insert into T_BLOG_TAG
   (ID, TAG_NAME, ARTICLE_ID)
 Values
   (124, 'test', 121);
COMMIT;
